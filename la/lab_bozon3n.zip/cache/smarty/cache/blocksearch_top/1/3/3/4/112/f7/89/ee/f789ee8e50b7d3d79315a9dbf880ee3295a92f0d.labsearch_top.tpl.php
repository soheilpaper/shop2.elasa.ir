<?php /*%%SmartyHeaderCode:2788255e734298cce03-86904268%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f789ee8e50b7d3d79315a9dbf880ee3295a92f0d' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\labsearch\\labsearch_top.tpl',
      1 => 1441113070,
      2 => 'file',
    ),
    '49885c9c6af177666ad1fd99a307d69b506e710b' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\modules\\labsearch\\labsearch_instant.tpl',
      1 => 1422253702,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2788255e734298cce03-86904268',
  'variables' => 
  array (
    'link' => 0,
    'search_query' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e73429b1a6b8_97763178',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e73429b1a6b8_97763178')) {function content_55e73429b1a6b8_97763178($_smarty_tpl) {?><div id="lab_search_ajaximg" class="pull-right">
	<div class="lab_search">
				<form id="searchbox" method="get" action="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/search" >
					<input type="hidden" name="controller" value="search" />
					<input type="hidden" name="orderby" value="position" />
					<input type="hidden" name="orderway" value="desc" />
					<input class="search_query form-control" type="text" id="search_query_top" name="search_query" placeholder="جستجو" value="" />
					<button type="submit" name="submit_search" class="btn btn-default button-search">
						<!-- <span>Search</span> -->
						<i class="icon-search"></i>
					</button>
				</form>
	</div>
</div> 

  <div id="search_autocomplete" class="search-autocomplete"></div>
		<script type="text/javascript">
		$('document').ready( function() {
			$("#search_query_top")
				.autocomplete(
					       '/prestashop/lab_bozon3/modules/labsearch/labsearchAjax.php',{
						minChars: 3,
						max: 10,
						width: 270,
						selectFirst: false,
						scroll: false,
						dataType: "json",
						formatItem: function(data, i, max, value, term) {
							return value;
						},
						parse: function(data) {
							var mytab = new Array();
							for (var i = 0; i < data.length; i++)
								mytab[mytab.length] = { data: data[i], value:' <img src="'+ data[i].ajaxsearchimage + '" />' + data[i].pname };
							return mytab;
						},
						extraParams: {
							ajaxSearch: 1,
							id_lang: 3
						}
					}
				)
				.result(function(event, data, formatted) {
					$('#search_query_top').val(data.pname);
					document.location.href = data.product_link;
				})
		});
	</script>

<?php }} ?>
