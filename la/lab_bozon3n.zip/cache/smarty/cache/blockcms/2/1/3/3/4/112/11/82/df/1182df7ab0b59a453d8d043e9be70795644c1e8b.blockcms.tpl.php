<?php /*%%SmartyHeaderCode:2747555e7342c40a884-27658507%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1182df7ab0b59a453d8d043e9be70795644c1e8b' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\blockcms\\blockcms.tpl',
      1 => 1435080624,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2747555e7342c40a884-27658507',
  'variables' => 
  array (
    'block' => 0,
    'cms_titles' => 0,
    'cms_key' => 0,
    'cms_title' => 0,
    'cms_page' => 0,
    'link' => 0,
    'show_price_drop' => 0,
    'PS_CATALOG_MODE' => 0,
    'show_new_products' => 0,
    'show_best_sales' => 0,
    'display_stores_footer' => 0,
    'show_contact' => 0,
    'contact_url' => 0,
    'cmslinks' => 0,
    'cmslink' => 0,
    'show_sitemap' => 0,
    'footer_text' => 0,
    'display_poweredby' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7342cb24149_78690450',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7342cb24149_78690450')) {function content_55e7342cb24149_78690450($_smarty_tpl) {?>
	<!-- MODULE Block footer -->
	<section class="footer-block col-lg-2 col-md-2 col-sm-4 col-xs-12 wow fadeInUp " data-wow-delay="400ms" id="block_various_links_footer">
		<h4>اطلاعات</h4>
		<ul class="toggle-footer">
							<li class="item">
					<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/prices-drop" title="محصولات ویژه">
						محصولات ویژه
					</a>
				</li>
									<li class="item">
				<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/new-products" title="محصولات جدید">
					محصولات جدید
				</a>
			</li>
										<li class="item">
					<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/best-sales" title="پرفروش ترین‌ ها">
						پرفروش ترین‌ ها
					</a>
				</li>
										<li class="item">
					<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/stores" title="فروشگاه های ما">
						فروشگاه های ما
					</a>
				</li>
									<li class="item">
				<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/contact-us" title="تماس با ما">
					تماس با ما
				</a>
			</li>
																																																						<li>
				<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/sitemap" title="نقشه سایت">
					نقشه سایت
				</a>
			</li>
					</ul>
		
	</section>
	<!--  -->
	<!-- /MODULE Block footer -->
<?php }} ?>
