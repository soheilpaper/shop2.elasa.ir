<?php /*%%SmartyHeaderCode:956455e7341ea6f9d4-76829611%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '602470a1badc98adbf25f2fd91912b7f0c8669d9' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\productscategory\\productscategory.tpl',
      1 => 1441106392,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '956455e7341ea6f9d4-76829611',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e74fbd8629c0_59304376',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e74fbd8629c0_59304376')) {function content_55e74fbd8629c0_59304376($_smarty_tpl) {?><section class="page-product-box blockproductscategory lablistproducts">
	<div class="title_block">
		<h4>
			<span> محصولاتی دیگر از این دست</span>
		</h4>
	</div>
	<div class="block_content row">
	<div id="productscategory_list">
									<div class="item-inner wow fadeInUp " data-wow-delay="100ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/-/1-faded-short-sleeves-tshirt.html" title=" فواره جت (نازل جت) ">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/174-home_default/faded-short-sleeves-tshirt.jpg" alt=" فواره جت (نازل جت) " />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/-/1-faded-short-sleeves-tshirt.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '1', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="1"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/-/1-faded-short-sleeves-tshirt.html" 
												data-product-name=" &#1601;&#1608;&#1575;&#1585;&#1607; &#1580;&#1578; (&#1606;&#1575;&#1586;&#1604; &#1580;&#1578;) "
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/174-cart_default/faded-short-sleeves-tshirt.jpg"
												data-id-product="1"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/-/1-faded-short-sleeves-tshirt.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/-/1-faded-short-sleeves-tshirt.html" title="&#1601;&#1608;&#1575;&#1585;&#1607; &#1580;&#1578; (&#1606;&#1575;&#1586;&#1604; &#1580;&#1578;)">&#1601;&#1608;&#1575;&#1585;&#1607; &#1580;&#1578; (&#1606;&#1575;&#1586;&#1604; &#1580;&#1578;)</a></h5>
															<div class="lab-price">
									<span class="price">86,400 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/cart?add=1&amp;id_product=1&amp;token=d4162ff63c24191de4edf04cdfbe0287"
													data-id-product="1"
													title="افزودن به سبد خرید" >
														<span>افزودن به سبد خرید</span>
													</a>
																		
																													</div>
							</div>
							
						</div>
					</div>
									</div>
													<div class="item-inner wow fadeInUp " data-wow-delay="200ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/13-fountain-nazzle.html" title="نازل کومت">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/171-home_default/fountain-nazzle.jpg" alt="نازل کومت" />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/13-fountain-nazzle.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '13', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="13"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/13-fountain-nazzle.html" 
												data-product-name="&#1606;&#1575;&#1586;&#1604; &#1705;&#1608;&#1605;&#1578;"
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/171-cart_default/fountain-nazzle.jpg"
												data-id-product="13"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/13-fountain-nazzle.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/13-fountain-nazzle.html" title="&#1606;&#1575;&#1586;&#1604; &#1705;&#1608;&#1605;&#1578;">&#1606;&#1575;&#1586;&#1604; &#1705;&#1608;&#1605;&#1578;</a></h5>
															<div class="lab-price">
									<span class="price">11,880 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/cart?add=1&amp;id_product=13&amp;token=d4162ff63c24191de4edf04cdfbe0287"
													data-id-product="13"
													title="افزودن به سبد خرید" >
														<span>افزودن به سبد خرید</span>
													</a>
																		
																													</div>
							</div>
							
						</div>
					</div>
									</div>
													<div class="item-inner wow fadeInUp " data-wow-delay="300ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/14--.html" title="پکیج آماده">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/176-home_default/-.jpg" alt="پکیج آماده" />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/14--.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '14', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="14"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/14--.html" 
												data-product-name="&#1662;&#1705;&#1740;&#1580; &#1570;&#1605;&#1575;&#1583;&#1607;"
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/176-cart_default/-.jpg"
												data-id-product="14"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/14--.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/14--.html" title="&#1662;&#1705;&#1740;&#1580; &#1570;&#1605;&#1575;&#1583;&#1607;">&#1662;&#1705;&#1740;&#1580; &#1570;&#1605;&#1575;&#1583;&#1607;</a></h5>
															<div class="lab-price">
									<span class="price">4,860,000 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																			<span class="old-price product-price">
											5,400,000 تومان
										</span>
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/cart?add=1&amp;id_product=14&amp;token=d4162ff63c24191de4edf04cdfbe0287"
													data-id-product="14"
													title="افزودن به سبد خرید" >
														<span>افزودن به سبد خرید</span>
													</a>
																		
																													</div>
							</div>
							
						</div>
					</div>
									</div>
													<div class="item-inner wow fadeInUp " data-wow-delay="400ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/15--.html" title=" نازل چرخشی">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/177-home_default/-.jpg" alt=" نازل چرخشی" />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/15--.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '15', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="15"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/15--.html" 
												data-product-name=" &#1606;&#1575;&#1586;&#1604; &#1670;&#1585;&#1582;&#1588;&#1740;"
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/177-cart_default/-.jpg"
												data-id-product="15"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/15--.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/15--.html" title="&#1606;&#1575;&#1586;&#1604; &#1670;&#1585;&#1582;&#1588;&#1740;">&#1606;&#1575;&#1586;&#1604; &#1670;&#1585;&#1582;&#1588;&#1740;</a></h5>
															<div class="lab-price">
									<span class="price">1,350,000 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																	<span class="button ajax_add_to_cart_button btn btn-default disabled">
													<span>افزودن به سبد خرید</span>
												</span>
																													</div>
							</div>
							
						</div>
					</div>
									</div>
													<div class="item-inner wow fadeInUp " data-wow-delay="500ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/16--.html" title="مولتی دایرکشنال">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/179-home_default/-.jpg" alt="مولتی دایرکشنال" />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/16--.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '16', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="16"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/16--.html" 
												data-product-name="&#1605;&#1608;&#1604;&#1578;&#1740; &#1583;&#1575;&#1740;&#1585;&#1705;&#1588;&#1606;&#1575;&#1604;"
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/179-cart_default/-.jpg"
												data-id-product="16"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/16--.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/16--.html" title="&#1605;&#1608;&#1604;&#1578;&#1740; &#1583;&#1575;&#1740;&#1585;&#1705;&#1588;&#1606;&#1575;&#1604;">&#1605;&#1608;&#1604;&#1578;&#1740; &#1583;&#1575;&#1740;&#1585;&#1705;&#1588;&#1606;&#1575;&#1604;</a></h5>
															<div class="lab-price">
									<span class="price">864,000 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																	<span class="button ajax_add_to_cart_button btn btn-default disabled">
													<span>افزودن به سبد خرید</span>
												</span>
																													</div>
							</div>
							
						</div>
					</div>
									</div>
													<div class="item-inner wow fadeInUp " data-wow-delay="600ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/17--.html" title="نازل بادبزن ">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/180-home_default/-.jpg" alt="نازل بادبزن " />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/17--.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '17', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="17"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/17--.html" 
												data-product-name="&#1606;&#1575;&#1586;&#1604; &#1576;&#1575;&#1583;&#1576;&#1586;&#1606; "
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/180-cart_default/-.jpg"
												data-id-product="17"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/17--.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/17--.html" title="&#1606;&#1575;&#1586;&#1604; &#1576;&#1575;&#1583;&#1576;&#1586;&#1606;">&#1606;&#1575;&#1586;&#1604; &#1576;&#1575;&#1583;&#1576;&#1586;&#1606;</a></h5>
															<div class="lab-price">
									<span class="price">194,400 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/cart?add=1&amp;id_product=17&amp;token=d4162ff63c24191de4edf04cdfbe0287"
													data-id-product="17"
													title="افزودن به سبد خرید" >
														<span>افزودن به سبد خرید</span>
													</a>
																		
																													</div>
							</div>
							
						</div>
					</div>
									</div>
													<div class="item-inner wow fadeInUp " data-wow-delay="700ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/18--.html" title="نازل رقص شیطان ">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/183-home_default/-.jpg" alt="نازل رقص شیطان " />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/18--.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '18', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="18"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/18--.html" 
												data-product-name="&#1606;&#1575;&#1586;&#1604; &#1585;&#1602;&#1589; &#1588;&#1740;&#1591;&#1575;&#1606; "
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/183-cart_default/-.jpg"
												data-id-product="18"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/18--.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/18--.html" title="&#1606;&#1575;&#1586;&#1604; &#1585;&#1602;&#1589; &#1588;&#1740;&#1591;&#1575;&#1606;">&#1606;&#1575;&#1586;&#1604; &#1585;&#1602;&#1589; &#1588;&#1740;&#1591;&#1575;&#1606;</a></h5>
															<div class="lab-price">
									<span class="price">205,200 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/cart?add=1&amp;id_product=18&amp;token=d4162ff63c24191de4edf04cdfbe0287"
													data-id-product="18"
													title="افزودن به سبد خرید" >
														<span>افزودن به سبد خرید</span>
													</a>
																		
																													</div>
							</div>
							
						</div>
					</div>
									</div>
													<div class="item-inner wow fadeInUp " data-wow-delay="800ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/19-nozzle.html" title="نازل پنجه ای ">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/185-home_default/nozzle.jpg" alt="نازل پنجه ای " />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/19-nozzle.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '19', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="19"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/19-nozzle.html" 
												data-product-name="&#1606;&#1575;&#1586;&#1604; &#1662;&#1606;&#1580;&#1607; &#1575;&#1740; "
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/185-cart_default/nozzle.jpg"
												data-id-product="19"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/19-nozzle.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/19-nozzle.html" title="&#1606;&#1575;&#1586;&#1604; &#1662;&#1606;&#1580;&#1607; &#1575;&#1740;">&#1606;&#1575;&#1586;&#1604; &#1662;&#1606;&#1580;&#1607; &#1575;&#1740;</a></h5>
															<div class="lab-price">
									<span class="price">183,600 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/cart?add=1&amp;id_product=19&amp;token=d4162ff63c24191de4edf04cdfbe0287"
													data-id-product="19"
													title="افزودن به سبد خرید" >
														<span>افزودن به سبد خرید</span>
													</a>
																		
																													</div>
							</div>
							
						</div>
					</div>
									</div>
													<div class="item-inner wow fadeInUp " data-wow-delay="900ms" >
									<div class="item">
						<div class="topItem">
							<div class="lab-img">
								
									<a class = "product_image" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/20--.html" title="نازل گل لاله ">
										<img class="img-responsive" src="http://127.0.0.1:8888/prestashop/lab_bozon3/188-home_default/-.jpg" alt="نازل گل لاله " />							
									</a>
								
																<a class="new-box" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/20--.html">
									<span class="new-label">جدید</span>
								</a>
																							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '20', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="20"
										title="افزودن به لیست محبوب ترین ها">
										<i class="icon-heart"></i></a>
									</li>
																			<li class="lab-compare">	
											<a class="add_to_compare" 
												href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/20--.html" 
												data-product-name="&#1606;&#1575;&#1586;&#1604; &#1711;&#1604; &#1604;&#1575;&#1604;&#1607; "
												data-product-cover="http://127.0.0.1:8888/prestashop/lab_bozon3/188-cart_default/-.jpg"
												data-id-product="20"
					
										
												title="افزودن به لیست مقایسه">
												<i class="icon-retweet"></i>
											</a>
										</li>
																		
																			<li class="lab-quick-view">
											<a class="quick-view" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/20--.html" 
												title="نگاه اجمالی">
												<i class="icon-eye-open"></i>
											</a>
										</li>
																		
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/20--.html" title="&#1606;&#1575;&#1586;&#1604; &#1711;&#1604; &#1604;&#1575;&#1604;&#1607;">&#1606;&#1575;&#1586;&#1604; &#1711;&#1604; &#1604;&#1575;&#1604;&#1607;</a></h5>
															<div class="lab-price">
									<span class="price">0 تومان</span>
									<meta itemprop="priceCurrency" content="0" />
																	</div>
														
							<div class="lab-cart">
								<div class="lab-cart-i">
																																														<a class="button ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/cart?add=1&amp;id_product=20&amp;token=d4162ff63c24191de4edf04cdfbe0287"
													data-id-product="20"
													title="افزودن به سبد خرید" >
														<span>افزودن به سبد خرید</span>
													</a>
																		
																													</div>
							</div>
							
						</div>
					</div>
									</div>
							</div>
	</div>
</section>
		<script>
			$(document).ready(function() {
			var owl = $("#productscategory_list");
			owl.owlCarousel({
				autoPlay : false,
				items :4,
				itemsDesktop : [1200,3],
				itemsDesktopSmall : [991,3],
				itemsTablet: [767,2],
				itemsMobile : [480,2],
			});
			/*	$(".nextspecial").click(function(){
				owl.trigger('owl.next');
				})
				$(".prevspecial").click(function(){
				owl.trigger('owl.prev');
				})  */   
			});
		</script>
<?php }} ?>
