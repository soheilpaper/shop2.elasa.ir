<?php /*%%SmartyHeaderCode:1140855e7342cb5d164-80311191%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1c5d0c032028cd37dcaf31417ab2b51eee46ebf7' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\blockmyaccountfooter\\blockmyaccountfooter.tpl',
      1 => 1435080638,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1140855e7342cb5d164-80311191',
  'variables' => 
  array (
    'link' => 0,
    'returnAllowed' => 0,
    'voucherAllowed' => 0,
    'HOOK_BLOCK_MY_ACCOUNT' => 0,
    'is_logged' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7342d081cc0_40905512',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7342d081cc0_40905512')) {function content_55e7342d081cc0_40905512($_smarty_tpl) {?>
<!-- Block myaccount module -->
<section class="footer-block col-lg-2 col-md-2 col-sm-4 col-xs-12 wow fadeInUp " data-wow-delay="500ms">
	<h4><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/my-account" title="مدیریت حساب کاربری شما" rel="nofollow">حساب کاربری</a></h4>
	<div class="block_content toggle-footer">
		<ul class="bullet">
			<li><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/order-history" title="سفارشات من" rel="nofollow">سفارشات من</a></li>
						<li><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/credit-slip" title="صورت های مالی من" rel="nofollow">صورت های مالی من</a></li>
			<li><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/addresses" title="آدرس های من" rel="nofollow">آدرس های من</a></li>
			<li><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/identity" title="مدیریت اطلاعات شخصی شما" rel="nofollow">اطلاعات شخصی شما</a></li>
						
            <li><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/?mylogout" title="خروج از حساب" rel="nofollow">خروج از حساب</a></li>		</ul>
	</div>
</section>
<!-- /Block myaccount module -->
<?php }} ?>
