<?php /*%%SmartyHeaderCode:1690155e74935138c91-75272404%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a94ccf9df0bb1a172c49a7da25dfdf10529ea64f' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\smartbloghomelatestnews\\views\\templates\\front\\smartblog_latest_news.tpl',
      1 => 1434569626,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1690155e74935138c91-75272404',
  'variables' => 
  array (
    'view_data' => 0,
    'post' => 0,
    'options' => 0,
    'modules_dir' => 0,
    'i' => 0,
    'languages' => 0,
    'language' => 0,
    'lang_iso' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e749355fd851_14555606',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e749355fd851_14555606')) {function content_55e749355fd851_14555606($_smarty_tpl) {?><div class="lablistproducts  labnewsmartblog col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class='title_block'>
		<h4>
			<span>آخرین اخبار</span>
		</h4>
	</div>
	<div class="blogviewMore">
		<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog.html">
			<span>وبلاگ های بیشتری را مشاهده نمایید </span>
		</a>
	</div>
    <div class="row">
    <div class="sdsblog-box-content">
                                                                                                                <div class="item-inner wow fadeInUp " data-wow-delay="100ms">
						<div class="item-i">
							<div class="news_module_image_holder">
								 <a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/4_share-the-love-for-prestashop-1-6.html"><img alt="Share the Love for PrestaShop 1.6" class="feat_img_small" src="/prestashop/lab_bozon3/modules/smartblog/images/4-home-default.jpg"></a>
								<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/4_share-the-love-for-prestashop-1-6.html" title="ادامه مطلب"  class="r_more"><span><i class="icon-eye-open"></i></span></a>
							</div>
							
							<h2 class="labname"><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/4_share-the-love-for-prestashop-1-6.html">Share the Love for PrestaShop 1.6</a></h2>
							
							<p class="short_description">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever...
								
							</p>
							
						</div>
                    </div>
                
                                                                                                            <div class="item-inner wow fadeInUp " data-wow-delay="200ms">
						<div class="item-i">
							<div class="news_module_image_holder">
								 <a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/3_answer-to-your-question-about-prestashop-1-6.html"><img alt="Answers to your Questions about PrestaShop 1.6" class="feat_img_small" src="/prestashop/lab_bozon3/modules/smartblog/images/3-home-default.jpg"></a>
								<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/3_answer-to-your-question-about-prestashop-1-6.html" title="ادامه مطلب"  class="r_more"><span><i class="icon-eye-open"></i></span></a>
							</div>
							
							<h2 class="labname"><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/3_answer-to-your-question-about-prestashop-1-6.html">Answers to your Questions about PrestaShop 1.6</a></h2>
							
							<p class="short_description">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever...
								
							</p>
							
						</div>
                    </div>
                
                                                                                                            <div class="item-inner wow fadeInUp " data-wow-delay="300ms">
						<div class="item-i">
							<div class="news_module_image_holder">
								 <a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/2_what-is-bootstrap.html"><img alt="What is Bootstrap? – The History and the Hype" class="feat_img_small" src="/prestashop/lab_bozon3/modules/smartblog/images/2-home-default.jpg"></a>
								<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/2_what-is-bootstrap.html" title="ادامه مطلب"  class="r_more"><span><i class="icon-eye-open"></i></span></a>
							</div>
							
							<h2 class="labname"><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/2_what-is-bootstrap.html">What is Bootstrap? – The History and the Hype</a></h2>
							
							<p class="short_description">
								Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever...
								
							</p>
							
						</div>
                    </div>
                
                                                                                                            <div class="item-inner wow fadeInUp " data-wow-delay="400ms">
						<div class="item-i">
							<div class="news_module_image_holder">
								 <a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/1_from-now-we-are-certified-web-agency.html"><img alt="From Now we are certified web agency" class="feat_img_small" src="/prestashop/lab_bozon3/modules/smartblog/images/1-home-default.jpg"></a>
								<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/1_from-now-we-are-certified-web-agency.html" title="ادامه مطلب"  class="r_more"><span><i class="icon-eye-open"></i></span></a>
							</div>
							
							<h2 class="labname"><a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/smartblog/1_from-now-we-are-certified-web-agency.html">From Now we are certified web agency</a></h2>
							
							<p class="short_description">
								Smartdatasoft is an offshore web development company located in Bangladesh. We are serving this sector since 2010. Our team is committed...
								
							</p>
							
						</div>
                    </div>
                
                                         </div>
    </div>
	<!-- <div class="lab_boxnp">
		<a class="prev labnewblogprev"><i class="icon-angle-left"></i></a>
		<a class="next labnewblognext"><i class="icon-angle-right"></i></a>
	</div> -->
</div>
						<script>
    $(document).ready(function() {
	var owl = $(".sdsblog-box-content");
    owl.owlCarousel({
		autoPlay : false,
		items :3,
		itemsDesktop : [1200,3],
		itemsDesktopSmall : [991,2],
		itemsTablet: [767,2],
		itemsMobile : [480,1],
	});
	$(".labnewblognext").click(function(){
	owl.trigger('owl.next');
	})
	$(".labnewblogprev").click(function(){
	owl.trigger('owl.prev');
	})
    });
</script><?php }} ?>
