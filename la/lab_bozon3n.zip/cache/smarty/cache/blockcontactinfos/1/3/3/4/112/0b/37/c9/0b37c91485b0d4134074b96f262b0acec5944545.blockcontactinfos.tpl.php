<?php /*%%SmartyHeaderCode:464455e7342ba907f1-21269638%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b37c91485b0d4134074b96f262b0acec5944545' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\blockcontactinfos\\blockcontactinfos.tpl',
      1 => 1435080544,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '464455e7342ba907f1-21269638',
  'variables' => 
  array (
    'blockcontactinfos_company' => 0,
    'blockcontactinfos_address' => 0,
    'blockcontactinfos_phone' => 0,
    'blockcontactinfos_email' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7342bced1c3_57450489',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7342bced1c3_57450489')) {function content_55e7342bced1c3_57450489($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos" class="footer-block col-lg-3 col-md-3 col-sm-6 col-xs-12 wow fadeInUp " data-wow-delay="200ms">
        <h4>اطلاعات فروشگاه</h4>
        <ul class="toggle-footer">
                        	<li>
            		<i class="icon-map-marker"></i>شرکت الکتروآسای بیهق, ایران - خراسان رضوی
سبزوار - خ قائم 13لاک 6            	</li>
                                    	<li>
            		<i class="icon-phone"></i>هم اکنون با ما تماس بگیرید: 
            		<span>+989120258354</span>
            	</li>
                                    	<li>
            		<i class="icon-envelope"></i>ایمیل: 
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%73%6f%68%65%69%6c%5f%70%61%70%65%72@%79%61%68%6f%6f.%63%6f%6d" >&#x73;&#x6f;&#x68;&#x65;&#x69;&#x6c;&#x5f;&#x70;&#x61;&#x70;&#x65;&#x72;&#x40;&#x79;&#x61;&#x68;&#x6f;&#x6f;&#x2e;&#x63;&#x6f;&#x6d;</a></span>
            	</li>
                    </ul>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>
