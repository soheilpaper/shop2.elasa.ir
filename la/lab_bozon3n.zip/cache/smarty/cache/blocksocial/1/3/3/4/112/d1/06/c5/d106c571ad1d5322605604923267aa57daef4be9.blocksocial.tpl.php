<?php /*%%SmartyHeaderCode:2705555e7342d44f2a8-70965958%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd106c571ad1d5322605604923267aa57daef4be9' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1434569952,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2705555e7342d44f2a8-70965958',
  'variables' => 
  array (
    'facebook_url' => 0,
    'twitter_url' => 0,
    'rss_url' => 0,
    'youtube_url' => 0,
    'google_plus_url' => 0,
    'pinterest_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7342d6e0332_59982093',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7342d6e0332_59982093')) {function content_55e7342d6e0332_59982093($_smarty_tpl) {?><section id="social_block" class="footer-block wow fadeInUp " data-wow-delay="700ms">
	<h4>ما را دنبال کنید</h4>
	<div class="block_content toggle-footer">
	<ul>
					<li class="facebook">
				<a 	target="_blank" href="http://www.facebook.com/prestashop"
					title="فیسبوک" >
						<i class="icon-facebook"></i>
				</a>
			</li>
							<li class="twitter">
				<a 	target="_blank" href="http://www.twitter.com/prestashop"
					title="توئیتر" >
						<i class="icon-twitter"></i>
				</a>
			</li>
							<li class="rss">
				<a 	target="_blank" href="http://www.prestashop.com/blog/en/"
					title="خوراک (RSS)" >
						<i class="icon-rss"></i>
				</a>
			</li>
		                        	<li class="google-plus">
				<a 	target="_blank" href="https://www.google.com/+prestashop"
					title="گوگل پلاس" >
						<i class="icon-google-plus"></i>
				</a>
        	</li>
                	</ul>
    </div>
</section>
<div class="clearfix"></div>
<?php }} ?>
