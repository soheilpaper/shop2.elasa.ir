<?php /*%%SmartyHeaderCode:2247955e7341e7d51f9-68093470%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '547839850c418ee85bef029db8a8d112339e9435' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\modules\\labmanagerblocks\\block.tpl',
      1 => 1420718070,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2247955e7341e7d51f9-68093470',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7342b9bf026_67680202',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7342b9bf026_67680202')) {function content_55e7342b9bf026_67680202($_smarty_tpl) {?>     	  	  <p><img src="http://127.0.0.1:8888/prestashop/lab_bozon3/img/cms/arm_elasa11_3.jpg" alt="" width="54" height="56" /></p>
	       <?php }} ?>
