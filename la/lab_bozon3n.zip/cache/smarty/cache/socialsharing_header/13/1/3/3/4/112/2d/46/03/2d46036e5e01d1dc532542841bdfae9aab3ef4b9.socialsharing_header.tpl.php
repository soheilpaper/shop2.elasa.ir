<?php /*%%SmartyHeaderCode:943155e7341862edd0-81954159%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2d46036e5e01d1dc532542841bdfae9aab3ef4b9' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\modules\\socialsharing\\views\\templates\\hook\\socialsharing_header.tpl',
      1 => 1431459418,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '943155e7341862edd0-81954159',
  'variables' => 
  array (
    'request' => 0,
    'meta_title' => 0,
    'shop_name' => 0,
    'meta_description' => 0,
    'link_rewrite' => 0,
    'cover' => 0,
    'link' => 0,
    'pretax_price' => 0,
    'currency' => 0,
    'price' => 0,
    'weight' => 0,
    'weight_unit' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7341894d094_78474916',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7341894d094_78474916')) {function content_55e7341894d094_78474916($_smarty_tpl) {?><meta property="og:type" content="product" /> 
<meta property="og:url" content="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/home/13-fountain-nazzle.html" /> 
<meta property="og:title" content="آبنما نازل" /> 
<meta property="og:site_name" content="Lab Bozon" />
<meta property="og:description" content="آبنما نازل" />
<meta property="og:image" content="http://127.0.0.1:8888/prestashop/lab_bozon3/171-large_default/fountain-nazzle.jpg" />
<meta property="product:pretax_price:amount" content="11000" /> 
<meta property="product:pretax_price:currency" content="IRT" /> 
<meta property="product:price:amount" content="11880" /> 
<meta property="product:price:currency" content="IRT" /> 
<meta property="product:weight:value" content="100.000000" /> 
<meta property="product:weight:units" content="گرم" /> 
<?php }} ?>
