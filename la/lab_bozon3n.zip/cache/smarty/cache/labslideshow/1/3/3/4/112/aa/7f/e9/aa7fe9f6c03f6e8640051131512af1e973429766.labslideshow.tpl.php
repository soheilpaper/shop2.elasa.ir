<?php /*%%SmartyHeaderCode:1901755e74926437e23-06412656%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa7fe9f6c03f6e8640051131512af1e973429766' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\labslideshow\\views\\templates\\hook\\labslideshow.tpl',
      1 => 1432063854,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1901755e74926437e23-06412656',
  'variables' => 
  array (
    'page_name' => 0,
    'labslideshow_slides' => 0,
    'slide' => 0,
    'link' => 0,
    'labslideshow' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7492f7e0d53_34013378',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7492f7e0d53_34013378')) {function content_55e7492f7e0d53_34013378($_smarty_tpl) {?>    <!-- Module labslideshow -->
    	<div class="lab-nivoSlideshow">
		<div class="lab-loading"></div>
        <div id="lab-slideshow" class="slides">
                                                                    <img 
									data-thumb="http://127.0.0.1:8888/prestashop/lab_bozon3/modules/labslideshow/images/ad25119d5e75e5ed670fad58b5deb0b7a3a733bd_144079-bellagio.jpg"  
									src="http://127.0.0.1:8888/prestashop/lab_bozon3/modules/labslideshow/images/ad25119d5e75e5ed670fad58b5deb0b7a3a733bd_144079-bellagio.jpg"
                                     alt="&#1601;&#1585;&#1608;&#1588; &#1608;&#1740;&#1688;&#1607; &#1570;&#1576;&#1606;&#1605;&#1575;"
									 title="#htmlcaption3" />
                                                                                        <img 
									data-thumb="http://127.0.0.1:8888/prestashop/lab_bozon3/modules/labslideshow/images/1b18b448a97b47cc46acd2432bd66958f2c284cf_1434972442392.jpg"  
									src="http://127.0.0.1:8888/prestashop/lab_bozon3/modules/labslideshow/images/1b18b448a97b47cc46acd2432bd66958f2c284cf_1434972442392.jpg"
                                     alt="&#1582;&#1585;&#1740;&#1583;&#1740; &#1585;&#1575;&#1581;&#1578;"
									 title="#htmlcaption4" />
                                            </div>
		
		        		<div id="htmlcaption3" class=" nivo-html-caption nivo-caption">
			<!-- <div class="timeline" style=" 
								position:absolute;
								top:0;
								left:0;
								background-color: rgba(49, 56, 72, 0.298);
								height:5px;
								-webkit-animation: myfirst 4000ms ease-in-out;
								-moz-animation: myfirst 4000ms ease-in-out;
								-ms-animation: myfirst 4000ms ease-in-out;
								animation: myfirst 4000ms ease-in-out;
							
							">
			</div> -->
			<div class="lab_description active right">
						<div class="title">
				<a href="#" title="طراحی انواع آبنما">					طراحی انواع آبنما
				</a>			</div>
									<div class="lab_caption">
				<span>فروش ویژه آبنما</span>
			</div>
									<div class="description ">
				<p style="text-align:center;">فروش ویژه آبنماهای کوچک</p>
			</div>
					<!-- 				<div class="readmore animated a3">
				<a href="#">Readmore</a>
			</div>
			 -->
			</div>
		</div>
		                		<div id="htmlcaption4" class=" nivo-html-caption nivo-caption">
			<!-- <div class="timeline" style=" 
								position:absolute;
								top:0;
								left:0;
								background-color: rgba(49, 56, 72, 0.298);
								height:5px;
								-webkit-animation: myfirst 4000ms ease-in-out;
								-moz-animation: myfirst 4000ms ease-in-out;
								-ms-animation: myfirst 4000ms ease-in-out;
								animation: myfirst 4000ms ease-in-out;
							
							">
			</div> -->
			<div class="lab_description active right">
						<div class="title">
				<a href="#" title="خرید انواع وسایل آبنما از سایت ما">					خرید انواع وسایل آبنما از سایت ما
				</a>			</div>
									<div class="lab_caption">
				<span>خریدی راحت</span>
			</div>
									<div class="description ">
				<p>فروش ویژه تجهیزات آبنما در</p>
<p><a class="btn btn-default" href="http://shop.elasa.ir" target="_blank">shop.elasa.ir</a></p>
			</div>
					<!-- 				<div class="readmore animated a3">
				<a href="#">Readmore</a>
			</div>
			 -->
			</div>
		</div>
		        	</div>
	<!-- <pre class='xdebug-var-dump' dir='ltr'>
<b>array</b>
  'languages' <font color='#888a85'>=&gt;</font> 
    <b>array</b>
      0 <font color='#888a85'>=&gt;</font> 
        <b>array</b>
          'id_lang' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'name' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'English (English)'</font> <i>(length=17)</i>
          'active' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'iso_code' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'en'</font> <i>(length=2)</i>
          'language_code' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'en-us'</font> <i>(length=5)</i>
          'date_format_lite' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'m/d/Y'</font> <i>(length=5)</i>
          'date_format_full' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'m/d/Y H:i:s'</font> <i>(length=11)</i>
          'is_rtl' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'0'</font> <i>(length=1)</i>
          'id_shop' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'shops' <font color='#888a85'>=&gt;</font> 
            <b>array</b>
              ...
      1 <font color='#888a85'>=&gt;</font> 
        <b>array</b>
          'id_lang' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'2'</font> <i>(length=1)</i>
          'name' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'Français (French)'</font> <i>(length=18)</i>
          'active' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'iso_code' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'fr'</font> <i>(length=2)</i>
          'language_code' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'fr-fr'</font> <i>(length=5)</i>
          'date_format_lite' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'d/m/Y'</font> <i>(length=5)</i>
          'date_format_full' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'d/m/Y H:i:s'</font> <i>(length=11)</i>
          'is_rtl' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'id_shop' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'shops' <font color='#888a85'>=&gt;</font> 
            <b>array</b>
              ...
      2 <font color='#888a85'>=&gt;</font> 
        <b>array</b>
          'id_lang' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'3'</font> <i>(length=1)</i>
          'name' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'فارسى (Persian)'</font> <i>(length=20)</i>
          'active' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'iso_code' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'fa'</font> <i>(length=2)</i>
          'language_code' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'fa-ir'</font> <i>(length=5)</i>
          'date_format_lite' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'Y-m-d'</font> <i>(length=5)</i>
          'date_format_full' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'Y-m-d H:i:s'</font> <i>(length=11)</i>
          'is_rtl' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'id_shop' <font color='#888a85'>=&gt;</font> <small>string</small> <font color='#cc0000'>'1'</font> <i>(length=1)</i>
          'shops' <font color='#888a85'>=&gt;</font> 
            <b>array</b>
              ...
  'LAB_PAUSE' <font color='#888a85'>=&gt;</font> <small>int</small> <font color='#4e9a06'>4000</font>
  'LAB_SPEED' <font color='#888a85'>=&gt;</font> <small>int</small> <font color='#4e9a06'>300</font>
  'LAB_E_N_P' <font color='#888a85'>=&gt;</font> <small>boolean</small> <font color='#75507b'>false</font>
  'LAB_E_CONTROL' <font color='#888a85'>=&gt;</font> <small>boolean</small> <font color='#75507b'>true</font>
  'LAB_TITLE' <font color='#888a85'>=&gt;</font> <small>boolean</small> <font color='#75507b'>true</font>
</pre> -->
<script type="text/javascript">
    $(window).load(function() {
		$(document).off('mouseenter').on('mouseenter', '.lab-nivoSlideshow', function(e){
			$('.lab-nivoSlideshow .timeline').addClass('lab_hover');
		});

		$(document).off('mouseleave').on('mouseleave', '.lab-nivoSlideshow', function(e){
			$('.lab-nivoSlideshow .timeline').removeClass('lab_hover');
		});
        $('#lab-slideshow').nivoSlider({
			effect: 'random',
			slices: 15,
			boxCols: 8,
			boxRows: 4,
			animSpeed: '300',
			pauseTime: '4000',
			startSlide: 0,
			directionNav: false,
			controlNav:  true ,
			controlNavThumbs: false,
			pauseOnHover: true,
			manualAdvance: false,
			prevText: '<i class="icon-double-angle-left"></i>',
			nextText: '<i class="icon-double-angle-right"></i>',
                        afterLoad: function(){
                         $('.lab-loading').css("display","none");
                        },     
						beforeChange: function(){ 
                            $('.nivo-caption .lab_description').removeClass("active").css("opacity","0");
                        },
                        afterChange: function(){ 
                            $('.nivo-caption .lab_description').addClass("active" ).css("opacity","1");
                        }
 		});
    });
    </script>
        <!-- /Module labslideshow -->
<?php }} ?>
