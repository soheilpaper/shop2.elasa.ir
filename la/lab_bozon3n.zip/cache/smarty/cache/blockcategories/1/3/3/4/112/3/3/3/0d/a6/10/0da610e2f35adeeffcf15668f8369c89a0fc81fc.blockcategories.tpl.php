<?php /*%%SmartyHeaderCode:1614755e741d270fb14-98148694%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0da610e2f35adeeffcf15668f8369c89a0fc81fc' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1425627560,
      2 => 'file',
    ),
    '3790622bb6e368cb71d31036646c077d1fa23eb1' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1425627560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1614755e741d270fb14-98148694',
  'variables' => 
  array (
    'blockCategTree' => 0,
    'currentCategory' => 0,
    'isDhtml' => 0,
    'child' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e741d2a07cc2_67114309',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e741d2a07cc2_67114309')) {function content_55e741d2a07cc2_67114309($_smarty_tpl) {?><!-- Block categories module -->
<div id="categories_block_left" class="block">
	<h2 class="title_block">
					نازل های آبنما
			</h2>
	<div class="block_content">
		<ul class="tree dhtml">
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/23-jewelry" title="">
		jewelry
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/43-footwear" title="">
		Footwear
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/42-lookbook" title="">
		Lookbook
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/41-conditions" title="">
		Conditions
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/40-jean-trousers" title="">
		Jean &amp; Trousers
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/39-conditions" title="">
		Conditions
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/21-accessories" title="">
		Accessories
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/33-bag-persess" title="">
		Bag &amp; Persess
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/32-gifts" title="">
		Gifts
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/31-handbags" title="">
		Handbags
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/30-clothing" title="">
		Clothing
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/29-lorem-ipsum" title="">
		Lorem Ipsum
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/20-watches" title="">
		watches
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/24-conditions" title="">
		Conditions
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/25-jewelry" title="">
		jewelry
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/26-lookbook" title="">
		Lookbook
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/28-lorem-ipsum" title="">
		Lorem Ipsum
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/27-dresses" title="">
		Dresses
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/22-sports" title="">
		Sports
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/38-electronic" title="">
		Electronic
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/37-handbags" title="">
		Handbags
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/36-lookbook" title="">
		Lookbook
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/35-cocktail" title="">
		Cocktail
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/34-shirts-tops" title="">
		Shirts &amp; Tops
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/4-tops" title="Choose from t-shirts, tops, blouses, short sleeves, long sleeves, tank tops, 3/4 sleeves and more. 
 Find the cut that suits you the best!">
		Tops
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/17-lookbook" title="">
		Lookbook
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/16-delivery" title="">
		Delivery
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/7-blouses" title="Match your favorites blouses with the right accessories for the perfect look.">
		Blouses
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/6-top" title="Choose the top that best suits you from the wide variety of tops we have.">
		Tops
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/5-tshirts" title="The must have of your wardrobe, take a look at our different colors, 
 shapes and style of our collection!">
		T-shirts
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/8-dresses" title="Find your favorites dresses from our wide choice of evening, casual or summer dresses! 
 We offer dresses for every day, every style and every occasion.">
		Dresses
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/19-privacy-policy" title="">
		Privacy &amp; Policy
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/18-electronic" title="">
		Electronic
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/11-summer-dresses" title="Short dress, long dress, silk dress, printed dress, you will find the perfect dress for summer.">
		Summer Dresses
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/10-evening-dresses" title="Browse our different dresses to choose the perfect dress for an unforgettable evening!">
		Evening Dresses
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/9-casual-dresses" title="You are looking for a dress for every day? Take a look at 
 our selection of dresses to find one that suits you.">
		Casual Dresses
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</div>
</div>
<!-- /Block categories module -->
<?php }} ?>
