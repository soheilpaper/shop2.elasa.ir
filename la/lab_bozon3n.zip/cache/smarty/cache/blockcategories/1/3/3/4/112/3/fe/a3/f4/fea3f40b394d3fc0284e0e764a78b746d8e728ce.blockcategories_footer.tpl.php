<?php /*%%SmartyHeaderCode:2497355e7342be2f718-37084392%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fea3f40b394d3fc0284e0e764a78b746d8e728ce' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\blockcategories\\blockcategories_footer.tpl',
      1 => 1435080560,
      2 => 'file',
    ),
    '3790622bb6e368cb71d31036646c077d1fa23eb1' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1425627560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2497355e7342be2f718-37084392',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e741b1a469a0_10391760',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e741b1a469a0_10391760')) {function content_55e741b1a469a0_10391760($_smarty_tpl) {?>
<!-- Block categories module -->
<section class="blockcategories_footer footer-block col-lg-2 col-md-2 col-sm-6 col-xs-12 wow fadeInUp " data-wow-delay="300ms">
	<h4>شاخه‌ها</h4>
	<div class="category_footer toggle-footer">
		<div class="list">
			<ul class="tree dhtml">
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/13--" title="">
		درایورها و کنترلرها
	</a>
	</li>

							
																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/12--" title="">
		واتر پمپ آبنما
	</a>
			<ul>
												
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/44-wathces" title="">
		wathces
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/47-dress" title="">
		Dress
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/48-bags" title="">
		Bags
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/49-cost-jackets" title="">
		Cost &amp; Jackets
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/51-jewellery" title="">
		Jewellery
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/50-beauty" title="">
		Beauty
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

							
																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/15--" title="">
		سایر محصولات
	</a>
	</li>

							
																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/14--led" title="">
		لامپ های LED
	</a>
	</li>

							
																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/3--" title="نازل های آبنما">
		نازل های آبنما
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/23-jewelry" title="">
		jewelry
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/43-footwear" title="">
		Footwear
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/42-lookbook" title="">
		Lookbook
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/41-conditions" title="">
		Conditions
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/40-jean-trousers" title="">
		Jean &amp; Trousers
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/39-conditions" title="">
		Conditions
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/21-accessories" title="">
		Accessories
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/33-bag-persess" title="">
		Bag &amp; Persess
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/32-gifts" title="">
		Gifts
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/31-handbags" title="">
		Handbags
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/30-clothing" title="">
		Clothing
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/29-lorem-ipsum" title="">
		Lorem Ipsum
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/20-watches" title="">
		watches
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/24-conditions" title="">
		Conditions
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/25-jewelry" title="">
		jewelry
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/26-lookbook" title="">
		Lookbook
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/28-lorem-ipsum" title="">
		Lorem Ipsum
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/27-dresses" title="">
		Dresses
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/22-sports" title="">
		Sports
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/38-electronic" title="">
		Electronic
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/37-handbags" title="">
		Handbags
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/36-lookbook" title="">
		Lookbook
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/35-cocktail" title="">
		Cocktail
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/34-shirts-tops" title="">
		Shirts &amp; Tops
	</a>
	</li>

									</ul>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/4-tops" title="Choose from t-shirts, tops, blouses, short sleeves, long sleeves, tank tops, 3/4 sleeves and more. 
 Find the cut that suits you the best!">
		Tops
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/17-lookbook" title="">
		Lookbook
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/16-delivery" title="">
		Delivery
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/7-blouses" title="Match your favorites blouses with the right accessories for the perfect look.">
		Blouses
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/6-top" title="Choose the top that best suits you from the wide variety of tops we have.">
		Tops
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/5-tshirts" title="The must have of your wardrobe, take a look at our different colors, 
 shapes and style of our collection!">
		T-shirts
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/8-dresses" title="Find your favorites dresses from our wide choice of evening, casual or summer dresses! 
 We offer dresses for every day, every style and every occasion.">
		Dresses
	</a>
			<ul>
												
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/19-privacy-policy" title="">
		Privacy &amp; Policy
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/18-electronic" title="">
		Electronic
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/11-summer-dresses" title="Short dress, long dress, silk dress, printed dress, you will find the perfect dress for summer.">
		Summer Dresses
	</a>
	</li>

																
<li >
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/10-evening-dresses" title="Browse our different dresses to choose the perfect dress for an unforgettable evening!">
		Evening Dresses
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/9-casual-dresses" title="You are looking for a dress for every day? Take a look at 
 our selection of dresses to find one that suits you.">
		Casual Dresses
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

							
										</ul>
		</div>
	</div> <!-- .category_footer -->
</section>
<!-- /Block categories module -->
<?php }} ?>
