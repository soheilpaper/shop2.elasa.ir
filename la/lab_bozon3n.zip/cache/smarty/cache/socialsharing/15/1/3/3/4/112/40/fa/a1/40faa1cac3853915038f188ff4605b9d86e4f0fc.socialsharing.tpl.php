<?php /*%%SmartyHeaderCode:868355e7341fc41444-78580968%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '40faa1cac3853915038f188ff4605b9d86e4f0fc' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\modules\\socialsharing\\views\\templates\\hook\\socialsharing.tpl',
      1 => 1431459418,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '868355e7341fc41444-78580968',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e73abe412773_37543385',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e73abe412773_37543385')) {function content_55e73abe412773_37543385($_smarty_tpl) {?>
	<p class="socialsharing_product list-inline no-print">
					<button data-type="twitter" type="button" class="btn btn-default btn-twitter social-sharing">
				<i class="icon-twitter"></i> توییت
				<!-- <img src="http://127.0.0.1:8888/prestashop/lab_bozon3/modules/socialsharing/img/twitter.gif" alt="Tweet" /> -->
			</button>
							<button data-type="facebook" type="button" class="btn btn-default btn-facebook social-sharing">
				<i class="icon-facebook"></i> اشتراک گذاری
				<!-- <img src="http://127.0.0.1:8888/prestashop/lab_bozon3/modules/socialsharing/img/facebook.gif" alt="Facebook Like" /> -->
			</button>
							<button data-type="google-plus" type="button" class="btn btn-default btn-google-plus social-sharing">
				<i class="icon-google-plus"></i> گوگل+
				<!-- <img src="http://127.0.0.1:8888/prestashop/lab_bozon3/modules/socialsharing/img/google.gif" alt="Google Plus" /> -->
			</button>
							<button data-type="pinterest" type="button" class="btn btn-default btn-pinterest social-sharing">
				<i class="icon-pinterest"></i> پینترست
				<!-- <img src="http://127.0.0.1:8888/prestashop/lab_bozon3/modules/socialsharing/img/pinterest.gif" alt="Pinterest" /> -->
			</button>
			</p>
<?php }} ?>
