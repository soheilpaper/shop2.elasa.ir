<?php /*%%SmartyHeaderCode:2052655e7341e5ccc35-73641058%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '33ec2581b0a99387ceb3357d93b4b1f080d5268e' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\productcomments\\productcomments_reviews.tpl',
      1 => 1425627560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2052655e7341e5ccc35-73641058',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7527b901167_02001201',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7527b901167_02001201')) {function content_55e7527b901167_02001201($_smarty_tpl) {?><?php }} ?>
