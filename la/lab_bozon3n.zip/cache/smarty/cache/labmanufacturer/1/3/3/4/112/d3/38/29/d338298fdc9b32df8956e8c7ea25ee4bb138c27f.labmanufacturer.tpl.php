<?php /*%%SmartyHeaderCode:2322355e7342b602c57-01865482%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd338298fdc9b32df8956e8c7ea25ee4bb138c27f' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\labmanufacturer\\labmanufacturer.tpl',
      1 => 1435255788,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2322355e7342b602c57-01865482',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e75b5765ac00_96999912',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e75b5765ac00_96999912')) {function content_55e75b5765ac00_96999912($_smarty_tpl) {?>
<!-- Block manufacturers module -->
<div id="lablogo" class="manufacturer-logo col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<!-- <h2 class="lab_title">		<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/manufacturers" title="Manufacturers">			<span>Manufacturers</span>
			</a>	</h2> -->
			<div class="static-block wow fadeInLeft " data-wow-delay="200ms">
			     	  	  <p><img src="http://127.0.0.1:8888/prestashop/lab_bozon3/img/cms/arm_elasa11_3.jpg" alt="" width="54" height="56" /></p>
	       
		</div>
		<div class="listmanufacturer">
	<div class="lab-manufacturer-logo wow fadeInRight " data-wow-delay="200ms">
					
							<div class="item-inner">
								<div class="item-i ">
						<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/2_-" title="More about الکتروآسای بیهق">
							<img src="http://127.0.0.1:8888/prestashop/lab_bozon3/img/m/2.jpg" alt="الکتروآسای بیهق" />
						</a>
					</div>
							</div>
										
							<div class="item-inner">
								<div class="item-i ">
						<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/5_-saer" title="More about شرکت saer">
							<img src="http://127.0.0.1:8888/prestashop/lab_bozon3/img/m/5.jpg" alt="شرکت saer" />
						</a>
					</div>
							</div>
										
							<div class="item-inner">
								<div class="item-i ">
						<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/7_-" title="More about شرکت آرین">
							<img src="http://127.0.0.1:8888/prestashop/lab_bozon3/img/m/7.jpg" alt="شرکت آرین" />
						</a>
					</div>
							</div>
										
							<div class="item-inner">
								<div class="item-i ">
						<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/6_-gso" title="More about شرکت فنی و مهندسی GSO">
							<img src="http://127.0.0.1:8888/prestashop/lab_bozon3/img/m/6.jpg" alt="شرکت فنی و مهندسی GSO" />
						</a>
					</div>
							</div>
										
							<div class="item-inner">
								<div class="item-i ">
						<a href="http://127.0.0.1:8888/prestashop/lab_bozon3/fa/16_-" title="More about مکانیک پمپ تهران ">
							<img src="http://127.0.0.1:8888/prestashop/lab_bozon3/img/m/16.jpg" alt="مکانیک پمپ تهران " />
						</a>
					</div>
							</div>
							</div>
	<a class="nextmanu"></a>
	<a class="prevmanu"></a>
	</div>
</div>
							
<script>
    $(document).ready(function() {
    var owl = $(".lab-manufacturer-logo");
	owl.owlCarousel({
		autoPlay : true,
		items :5,
		itemsDesktop : [1200,4],
		itemsDesktopSmall : [991,3],
		itemsTablet: [767,3],
		itemsMobile : [480,1],
	});
		$(".nextmanu").click(function(){
		owl.trigger('owl.next');
		})
		$(".prevmanu").click(function(){
		owl.trigger('owl.prev');
		})   
    });
</script>
<!-- /Block manufacturers module -->
<?php }} ?>
