<?php /*%%SmartyHeaderCode:1408655e734206c5872-36540786%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f0337397ba59b6c5e700622da25bb7c1644ac474' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\modules\\productpaymentlogos\\views\\templates\\hook\\productpaymentlogos.tpl',
      1 => 1436116630,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1408655e734206c5872-36540786',
  'variables' => 
  array (
    'banner_title' => 0,
    'banner_link' => 0,
    'module_dir' => 0,
    'banner_img' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e734208a1839_75012391',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e734208a1839_75012391')) {function content_55e734208a1839_75012391($_smarty_tpl) {?><!-- Productpaymentlogos module -->
<div id="product_payment_logos">
	<div class="box-security">
    <h5 class="product-heading-h5"></h5>
  			<img src="/prestashop/lab_bozon3/modules/productpaymentlogos/img/payment-logo.png" alt="" class="img-responsive" />
	    </div>
</div>
<!-- /Productpaymentlogos module -->
<?php }} ?>
