<?php /* Smarty version Smarty-3.1.19, created on 2015-09-02 22:18:24
         compiled from "E:\soheil\web_site_root\prestashop\lab_bozon3\admin2715su9gj\themes\default\template\controllers\products\helpers\tree\tree_associated_header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:856555e73668869b66-71413395%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '500889fc757f808ffcfc5e9aca0cfa1132a015b7' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\admin2715su9gj\\themes\\default\\template\\controllers\\products\\helpers\\tree\\tree_associated_header.tpl',
      1 => 1425627560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '856555e73668869b66-71413395',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'toolbar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e736688c7872_35669359',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e736688c7872_35669359')) {function content_55e736688c7872_35669359($_smarty_tpl) {?>

<div class="tree-panel-heading-controls clearfix"><?php if (isset($_smarty_tpl->tpl_vars['toolbar']->value)) {?><?php echo $_smarty_tpl->tpl_vars['toolbar']->value;?>
<?php }?></div>
<?php }} ?>
