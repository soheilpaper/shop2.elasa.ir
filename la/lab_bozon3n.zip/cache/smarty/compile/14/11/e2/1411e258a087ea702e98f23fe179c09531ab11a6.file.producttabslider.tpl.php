<?php /* Smarty version Smarty-3.1.19, created on 2015-09-02 23:38:35
         compiled from "E:\soheil\web_site_root\prestashop\lab_bozon3\themes\lab_bozon1\modules\labtabproductslider\producttabslider.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1881255e749337bdd36-42124793%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1411e258a087ea702e98f23fe179c09531ab11a6' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\labtabproductslider\\producttabslider.tpl',
      1 => 1441106276,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1881255e749337bdd36-42124793',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'productTabslider' => 0,
    'count' => 0,
    'productTab' => 0,
    'product' => 0,
    'PS_CATALOG_MODE' => 0,
    'comparator_max_item' => 0,
    'link' => 0,
    'quick_view' => 0,
    'restricted_country_mode' => 0,
    'priceDisplay' => 0,
    'add_prod_display' => 0,
    'static_token' => 0,
    'languages' => 0,
    'language' => 0,
    'lang_iso' => 0,
    'tab_effect' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e74934327a56_34314010',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e74934327a56_34314010')) {function content_55e74934327a56_34314010($_smarty_tpl) {?><div class="product-tabs-slider lablistproducts laberthemes">
	<div class="lab_tabs">
		<ul class="tabs"> 
		<?php $_smarty_tpl->tpl_vars['count'] = new Smarty_variable(0, null, 0);?>
		<?php  $_smarty_tpl->tpl_vars['productTab'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['productTab']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['productTabslider']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['productTab']->total= $_smarty_tpl->_count($_from);
 $_smarty_tpl->tpl_vars['productTab']->iteration=0;
 $_smarty_tpl->tpl_vars['productTab']->index=-1;
foreach ($_from as $_smarty_tpl->tpl_vars['productTab']->key => $_smarty_tpl->tpl_vars['productTab']->value) {
$_smarty_tpl->tpl_vars['productTab']->_loop = true;
 $_smarty_tpl->tpl_vars['productTab']->iteration++;
 $_smarty_tpl->tpl_vars['productTab']->index++;
 $_smarty_tpl->tpl_vars['productTab']->first = $_smarty_tpl->tpl_vars['productTab']->index === 0;
 $_smarty_tpl->tpl_vars['productTab']->last = $_smarty_tpl->tpl_vars['productTab']->iteration === $_smarty_tpl->tpl_vars['productTab']->total;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['posTabProduct']['first'] = $_smarty_tpl->tpl_vars['productTab']->first;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['posTabProduct']['last'] = $_smarty_tpl->tpl_vars['productTab']->last;
?>
			<li class="<?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['posTabProduct']['first']) {?>first_item<?php } elseif ($_smarty_tpl->getVariable('smarty')->value['foreach']['posTabProduct']['last']) {?>last_item<?php } else { ?><?php }?> <?php if ($_smarty_tpl->tpl_vars['count']->value==0) {?> active <?php }?>" rel="tab_<?php echo $_smarty_tpl->tpl_vars['productTab']->value['id'];?>
"  >
				<?php echo $_smarty_tpl->tpl_vars['productTab']->value['name'];?>

			</li>
				<?php $_smarty_tpl->tpl_vars['count'] = new Smarty_variable($_smarty_tpl->tpl_vars['count']->value+1, null, 0);?>
		<?php } ?>	
		</ul>
	</div>
	<?php if (Hook::exec('labtabproductslider')) {?>
		<div class="static-block">
			<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>"labtabproductslider"),$_smarty_tpl);?>

		</div>
	<?php }?>
	<div class="row">
	<div class="tab_container"> 
	<?php  $_smarty_tpl->tpl_vars['productTab'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['productTab']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['productTabslider']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['productTab']->key => $_smarty_tpl->tpl_vars['productTab']->value) {
$_smarty_tpl->tpl_vars['productTab']->_loop = true;
?>
		<div id="tab_<?php echo $_smarty_tpl->tpl_vars['productTab']->value['id'];?>
" class="tab_content">
			<div class="productTabContent productTabContent_<?php echo $_smarty_tpl->tpl_vars['productTab']->value['id'];?>
 product_list productContent">
			<?php  $_smarty_tpl->tpl_vars['product'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['product']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['productTab']->value['productInfo']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['product']->total= $_smarty_tpl->_count($_from);
 $_smarty_tpl->tpl_vars['product']->iteration=0;
 $_smarty_tpl->tpl_vars['product']->index=-1;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['myLoop']['iteration']=0;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['myLoop']['index']=-1;
foreach ($_from as $_smarty_tpl->tpl_vars['product']->key => $_smarty_tpl->tpl_vars['product']->value) {
$_smarty_tpl->tpl_vars['product']->_loop = true;
 $_smarty_tpl->tpl_vars['product']->iteration++;
 $_smarty_tpl->tpl_vars['product']->index++;
 $_smarty_tpl->tpl_vars['product']->first = $_smarty_tpl->tpl_vars['product']->index === 0;
 $_smarty_tpl->tpl_vars['product']->last = $_smarty_tpl->tpl_vars['product']->iteration === $_smarty_tpl->tpl_vars['product']->total;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['myLoop']['first'] = $_smarty_tpl->tpl_vars['product']->first;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['myLoop']['iteration']++;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['myLoop']['index']++;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['myLoop']['last'] = $_smarty_tpl->tpl_vars['product']->last;
?>
				
				<?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['myLoop']['index']%1==0||$_smarty_tpl->getVariable('smarty')->value['foreach']['myLoop']['first']) {?>
				<div class="item-inner wow fadeInUp " data-wow-delay="<?php echo $_smarty_tpl->getVariable('smarty')->value['foreach']['myLoop']['iteration'];?>
00ms" >
				<?php }?>
					<div class="item">
						<div class="topItem">
							<div class="lab-img">
								<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>'rotatorImg','product'=>$_smarty_tpl->tpl_vars['product']->value),$_smarty_tpl);?>

								<?php if (isset($_smarty_tpl->tpl_vars['product']->value['new'])&&$_smarty_tpl->tpl_vars['product']->value['new']==1) {?>
								<a class="new-box" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
">
									<span class="new-label"><?php echo smartyTranslate(array('s'=>'جدید','mod'=>'labtabproductslider'),$_smarty_tpl);?>
</span>
								</a>
								<?php }?>
								<?php if (isset($_smarty_tpl->tpl_vars['product']->value['on_sale'])&&$_smarty_tpl->tpl_vars['product']->value['on_sale']&&isset($_smarty_tpl->tpl_vars['product']->value['show_price'])&&$_smarty_tpl->tpl_vars['product']->value['show_price']&&!$_smarty_tpl->tpl_vars['PS_CATALOG_MODE']->value) {?>
									<a class="sale-box" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
">
										<span class="sale-label"><?php echo smartyTranslate(array('s'=>'حراج !','mod'=>'labtabproductslider'),$_smarty_tpl);?>
</span>
									</a>
								<?php }?>
							</div>
							<div class="actions">
								<ul class="add-to-links">				
									<li class="lab-Wishlist">
										<a onclick="WishlistCart('wishlist_block_list', 'add', '<?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
', $('#idCombination').val(), 1,'tabproduct'); return false;" class="add-wishlist wishlist_button" href="#"
										data-id-product="<?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
"
										title="<?php echo smartyTranslate(array('s'=>'Add to Wishlist','mod'=>'labtabproductslider'),$_smarty_tpl);?>
">
										<i class="icon-heart"></i></a>
									</li>
									<?php if (isset($_smarty_tpl->tpl_vars['comparator_max_item']->value)&&$_smarty_tpl->tpl_vars['comparator_max_item']->value) {?>
										<li class="lab-compare">	
											<a class="add_to_compare" 
												href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
" 
												data-product-name="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['name'], ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
"
												data-product-cover="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getImageLink($_smarty_tpl->tpl_vars['product']->value['link_rewrite'],$_smarty_tpl->tpl_vars['product']->value['id_image'],'cart_default'), ENT_QUOTES, 'UTF-8', true);?>
"
												data-id-product="<?php echo $_smarty_tpl->tpl_vars['product']->value['id_product'];?>
"
												title="<?php echo smartyTranslate(array('s'=>'Add to Compare','mod'=>'labtabproductslider'),$_smarty_tpl);?>
">
												<i class="icon-retweet"></i>
											</a>
										</li>
									<?php }?>
									
									<?php if (isset($_smarty_tpl->tpl_vars['quick_view']->value)&&$_smarty_tpl->tpl_vars['quick_view']->value) {?>
										<li class="lab-quick-view">
											<a class="quick-view" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
"
												title="<?php echo smartyTranslate(array('s'=>'Quick view','mod'=>'labtabproductslider'),$_smarty_tpl);?>
">
												<i class="icon-eye-open"></i>
											</a>
										</li>
									<?php }?>
									
								</ul>
								
							</div>
						</div>
						<div class="bottomItem">
							<h5 class="h5product-name">
								<a class="product-name" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_MODIFIER]['truncate'][0][0]->smarty_modifier_truncate($_smarty_tpl->tpl_vars['product']->value['name'],50,'...'), ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
"><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_MODIFIER]['truncate'][0][0]->smarty_modifier_truncate($_smarty_tpl->tpl_vars['product']->value['name'],35,'...'), ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</a></h5>
							<?php if ($_smarty_tpl->tpl_vars['product']->value['show_price']&&!isset($_smarty_tpl->tpl_vars['restricted_country_mode']->value)&&!$_smarty_tpl->tpl_vars['PS_CATALOG_MODE']->value) {?>
								<div class="lab-price">
									<span class="price"><?php if (!$_smarty_tpl->tpl_vars['priceDisplay']->value) {?><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['convertPrice'][0][0]->convertPrice(array('price'=>$_smarty_tpl->tpl_vars['product']->value['price']),$_smarty_tpl);?>
<?php } else { ?><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['convertPrice'][0][0]->convertPrice(array('price'=>$_smarty_tpl->tpl_vars['product']->value['price_tax_exc']),$_smarty_tpl);?>
<?php }?></span>
									<meta itemprop="priceCurrency" content="<?php echo $_smarty_tpl->tpl_vars['priceDisplay']->value;?>
" />
									<?php if (isset($_smarty_tpl->tpl_vars['product']->value['specific_prices'])&&$_smarty_tpl->tpl_vars['product']->value['specific_prices']&&isset($_smarty_tpl->tpl_vars['product']->value['specific_prices']['reduction'])&&$_smarty_tpl->tpl_vars['product']->value['specific_prices']['reduction']>0) {?>
										<span class="old-price product-price">
											<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['displayWtPrice'][0][0]->displayWtPrice(array('p'=>$_smarty_tpl->tpl_vars['product']->value['price_without_reduction']),$_smarty_tpl);?>

										</span>
									<?php }?>
								</div>
							<?php }?>
							<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>'displayProductListReviews','product'=>$_smarty_tpl->tpl_vars['product']->value),$_smarty_tpl);?>

							<div class="lab-cart">
								<div class="lab-cart-i">
										<?php if (($_smarty_tpl->tpl_vars['product']->value['id_product_attribute']==0||(isset($_smarty_tpl->tpl_vars['add_prod_display']->value)&&($_smarty_tpl->tpl_vars['add_prod_display']->value==1)))&&$_smarty_tpl->tpl_vars['product']->value['available_for_order']&&!isset($_smarty_tpl->tpl_vars['restricted_country_mode']->value)&&$_smarty_tpl->tpl_vars['product']->value['minimal_quantity']<=1&&$_smarty_tpl->tpl_vars['product']->value['customizable']!=2&&!$_smarty_tpl->tpl_vars['PS_CATALOG_MODE']->value) {?>
											<?php if (($_smarty_tpl->tpl_vars['product']->value['allow_oosp']||$_smarty_tpl->tpl_vars['product']->value['quantity']>0)) {?>
												<?php if (isset($_smarty_tpl->tpl_vars['static_token']->value)) {?>
													<a class="button ajax_add_to_cart_button btn btn-default" href="<?php ob_start();?><?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
<?php $_tmp3=ob_get_clean();?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getPageLink('cart',false,null,"add=1&amp;id_product=".$_tmp3."&amp;token=".((string)$_smarty_tpl->tpl_vars['static_token']->value),false), ENT_QUOTES, 'UTF-8', true);?>
"
													data-id-product="<?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
"
													title="<?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'labtabproductslider'),$_smarty_tpl);?>
" >
														<span><?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'labtabproductslider'),$_smarty_tpl);?>
</span>
													</a>
												<?php } else { ?>
													<a class="button ajax_add_to_cart_button btn btn-default" href="<?php ob_start();?><?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
<?php $_tmp4=ob_get_clean();?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getPageLink('cart',false,null,"add=1&amp;id_product=".$_tmp4."&amp;token=".((string)$_smarty_tpl->tpl_vars['static_token']->value),false), ENT_QUOTES, 'UTF-8', true);?>
"
													data-id-product="<?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
"
													title="<?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'labtabproductslider'),$_smarty_tpl);?>
">
														<span><?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'labtabproductslider'),$_smarty_tpl);?>
</span>
													</a>
												<?php }?>						
											<?php } else { ?>
												<span class="button ajax_add_to_cart_button btn btn-default disabled">
													<span><?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'labtabproductslider'),$_smarty_tpl);?>
</span>
												</span>
											<?php }?>
										<?php }?>
								</div>
							</div>
							
						</div>
					</div>
				<?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['myLoop']['iteration']%1==0||$_smarty_tpl->getVariable('smarty')->value['foreach']['myLoop']['last']) {?>
					</div>
				<?php }?>
			
			<?php } ?>
			</div>
				
	</div>
<?php  $_smarty_tpl->tpl_vars['language'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['language']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['languages']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['language']->key => $_smarty_tpl->tpl_vars['language']->value) {
$_smarty_tpl->tpl_vars['language']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['language']->key;
?>
	<?php if ($_smarty_tpl->tpl_vars['language']->value['iso_code']==$_smarty_tpl->tpl_vars['lang_iso']->value) {?>
		<?php $_smarty_tpl->tpl_vars['rtl'] = new Smarty_variable($_smarty_tpl->tpl_vars['language']->value['is_rtl'], null, 0);?>
	<?php }?>
<?php } ?>
	<script>
		$(document).ready(function() {
		var owl = $(".productTabContent_<?php echo $_smarty_tpl->tpl_vars['productTab']->value['id'];?>
");
		owl.owlCarousel({
				autoPlay : false,
				items :4,
				itemsDesktop : [1200,3],
				itemsDesktopSmall : [991,3],
				itemsTablet: [767,2],
				itemsMobile : [480,2],
			});	
			$(".nextproductTab").click(function(){
			owl.trigger('owl.next');
			})
			$(".prevproductTab").click(function(){
			owl.trigger('owl.prev');
			})		
		});
	</script>
	
	<?php } ?>	
	<!-- <div class="lab_boxnp">
		<a class="prev prevproductTab"><i class="icon-angle-left"></i></a>
		<a class="next nextproductTab"><i class="icon-angle-right"></i></a>
	</div> -->
</div> <!-- .tab_container -->
</div>
</div>
<script type="text/javascript"> 
	$(document).ready(function() {
		$(".tab_content").hide();
		$(".tab_content:first").show(); 
		$("ul.tabs li").click(function() {
			$("ul.tabs li").removeClass("active");
			$(this).addClass("active");
			$(".tab_content").hide();
			$(".tab_content").removeClass("animate1 <?php echo $_smarty_tpl->tpl_vars['tab_effect']->value;?>
");
			var activeTab = $(this).attr("rel"); 
			$("#"+activeTab) .addClass("animate1 <?php echo $_smarty_tpl->tpl_vars['tab_effect']->value;?>
");
			$("#"+activeTab).fadeIn(); 
		});
	});
</script><?php }} ?>
