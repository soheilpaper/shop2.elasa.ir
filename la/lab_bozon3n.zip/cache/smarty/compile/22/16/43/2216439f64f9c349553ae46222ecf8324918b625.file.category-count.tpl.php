<?php /* Smarty version Smarty-3.1.19, created on 2015-09-02 23:07:09
         compiled from "E:\soheil\web_site_root\prestashop\lab_bozon3\themes\lab_bozon1\category-count.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1339055e741d5792856-41392416%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2216439f64f9c349553ae46222ecf8324918b625' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\category-count.tpl',
      1 => 1425627560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1339055e741d5792856-41392416',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'category' => 0,
    'nb_products' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e741d58dff33_41807772',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e741d58dff33_41807772')) {function content_55e741d58dff33_41807772($_smarty_tpl) {?>
<span class="heading-counter"><?php if ((isset($_smarty_tpl->tpl_vars['category']->value)&&$_smarty_tpl->tpl_vars['category']->value->id==1)||(isset($_smarty_tpl->tpl_vars['nb_products']->value)&&$_smarty_tpl->tpl_vars['nb_products']->value==0)) {?><?php echo smartyTranslate(array('s'=>'There are no products in this category.'),$_smarty_tpl);?>
<?php } else { ?><?php if (isset($_smarty_tpl->tpl_vars['nb_products']->value)&&$_smarty_tpl->tpl_vars['nb_products']->value==1) {?><?php echo smartyTranslate(array('s'=>'There is 1 product.'),$_smarty_tpl);?>
<?php } elseif (isset($_smarty_tpl->tpl_vars['nb_products']->value)) {?><?php echo smartyTranslate(array('s'=>'There are %d products.','sprintf'=>$_smarty_tpl->tpl_vars['nb_products']->value),$_smarty_tpl);?>
<?php }?><?php }?></span>
<?php }} ?>
