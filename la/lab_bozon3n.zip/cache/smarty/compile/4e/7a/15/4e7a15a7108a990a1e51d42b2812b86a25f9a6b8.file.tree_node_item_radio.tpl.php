<?php /* Smarty version Smarty-3.1.19, created on 2015-09-02 22:36:58
         compiled from "E:\soheil\web_site_root\prestashop\lab_bozon3\admin2715su9gj\themes\default\template\helpers\tree\tree_node_item_radio.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2214255e73ac223ce44-13730433%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4e7a15a7108a990a1e51d42b2812b86a25f9a6b8' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\admin2715su9gj\\themes\\default\\template\\helpers\\tree\\tree_node_item_radio.tpl',
      1 => 1425627560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2214255e73ac223ce44-13730433',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'node' => 0,
    'input_name' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e73ac2430421_28890177',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e73ac2430421_28890177')) {function content_55e73ac2430421_28890177($_smarty_tpl) {?>
<li class="tree-item<?php if (isset($_smarty_tpl->tpl_vars['node']->value['disabled'])&&$_smarty_tpl->tpl_vars['node']->value['disabled']==true) {?> tree-item-disable<?php }?>">
	<label class="tree-item-name">
		<input type="radio" name="<?php echo $_smarty_tpl->tpl_vars['input_name']->value;?>
" value="<?php echo $_smarty_tpl->tpl_vars['node']->value['id_category'];?>
"<?php if (isset($_smarty_tpl->tpl_vars['node']->value['disabled'])&&$_smarty_tpl->tpl_vars['node']->value['disabled']==true) {?> disabled="disabled"<?php }?> />
		<i class="tree-dot"></i>
		<?php echo $_smarty_tpl->tpl_vars['node']->value['name'];?>

	</label>
</li><?php }} ?>
