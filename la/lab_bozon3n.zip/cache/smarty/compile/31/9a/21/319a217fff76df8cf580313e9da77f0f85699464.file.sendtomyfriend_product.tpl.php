<?php /* Smarty version Smarty-3.1.19, created on 2015-09-02 22:08:39
         compiled from "E:\soheil\web_site_root\prestashop\lab_bozon3\modules\sendtomyfriend\sendtomyfriend_product.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1669855e7341fba04a6-42565109%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '319a217fff76df8cf580313e9da77f0f85699464' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\modules\\sendtomyfriend\\sendtomyfriend_product.tpl',
      1 => 1441215342,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1669855e7341fba04a6-42565109',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'this_path' => 0,
    'modal_box' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7341fc115a2_70931312',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7341fc115a2_70931312')) {function content_55e7341fc115a2_70931312($_smarty_tpl) {?><!-- Module : Send to my friend -->
<li>
	<a title="<?php echo smartyTranslate(array('s'=>'Send to my friend','mod'=>'sendtomyfriend'),$_smarty_tpl);?>
" href="<?php echo $_smarty_tpl->tpl_vars['this_path']->value;?>
sendtomyfriend-form.php?id_product=<?php echo intval($_GET['id_product']);?>
<?php if ($_smarty_tpl->tpl_vars['modal_box']->value) {?>&amp;content_only=1" rel="shadowbox;height=500;width=580<?php }?>">
		<?php echo smartyTranslate(array('s'=>'Send to my friend','mod'=>'sendtomyfriend'),$_smarty_tpl);?>

	</a>
</li>
<!-- /Module : Send to my friend -->
<?php }} ?>
