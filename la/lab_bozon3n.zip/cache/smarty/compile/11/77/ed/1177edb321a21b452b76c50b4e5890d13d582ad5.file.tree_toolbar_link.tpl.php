<?php /* Smarty version Smarty-3.1.19, created on 2015-09-02 22:07:04
         compiled from "E:\soheil\web_site_root\prestashop\lab_bozon3\modules\labmanagerblocks\views\templates\admin\helpers\tree\tree_toolbar_link.tpl" */ ?>
<?php /*%%SmartyHeaderCode:156455e733c0eb6af9-46692503%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1177edb321a21b452b76c50b4e5890d13d582ad5' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\modules\\labmanagerblocks\\views\\templates\\admin\\helpers\\tree\\tree_toolbar_link.tpl',
      1 => 1420718070,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '156455e733c0eb6af9-46692503',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'link' => 0,
    'action' => 0,
    'id' => 0,
    'icon_class' => 0,
    'label' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e733c1058770_64678329',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e733c1058770_64678329')) {function content_55e733c1058770_64678329($_smarty_tpl) {?>
<a href="<?php echo $_smarty_tpl->tpl_vars['link']->value;?>
"<?php if (isset($_smarty_tpl->tpl_vars['action']->value)) {?> onclick="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
"<?php }?><?php if (isset($_smarty_tpl->tpl_vars['id']->value)) {?> id="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
"<?php }?> class="btn btn-default">
	<?php if (isset($_smarty_tpl->tpl_vars['icon_class']->value)) {?><i class="<?php echo $_smarty_tpl->tpl_vars['icon_class']->value;?>
"></i><?php }?>
	<?php echo smartyTranslate(array('s'=>$_smarty_tpl->tpl_vars['label']->value),$_smarty_tpl);?>

</a><?php }} ?>
