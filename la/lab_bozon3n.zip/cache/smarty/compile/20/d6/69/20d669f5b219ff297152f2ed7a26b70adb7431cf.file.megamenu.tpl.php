<?php /* Smarty version Smarty-3.1.19, created on 2015-09-02 22:08:50
         compiled from "E:\soheil\web_site_root\prestashop\lab_bozon3\themes\lab_bozon1\modules\labmegamenus\megamenu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:165655e7342a972185-79076235%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '20d669f5b219ff297152f2ed7a26b70adb7431cf' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\themes\\lab_bozon1\\modules\\labmegamenus\\megamenu.tpl',
      1 => 1426009280,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '165655e7342a972185-79076235',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'megamenu' => 0,
    'megamenumobile' => 0,
    'effect' => 0,
    'top_offset' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e7342aa5d890_98029021',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e7342aa5d890_98029021')) {function content_55e7342aa5d890_98029021($_smarty_tpl) {?><div class="nav-container hidden-xs">
    <div id="menubar-pc" class="lab_custommenu">
		<div class="menuCenter">
			<?php echo $_smarty_tpl->tpl_vars['megamenu']->value;?>

		</div>
    </div>
</div>
<div class="navmenu-mobile visible-xs">
	<h3 class="categ-title"><?php echo smartyTranslate(array('s'=>'Menu','mod'=>'labmegamenus'),$_smarty_tpl);?>
</h3>
	<div class="mobile-menu">
		<nav>
			<ul>
				<?php echo $_smarty_tpl->tpl_vars['megamenumobile']->value;?>

			</ul>
		</nav>
	</div>
</div>
<script type="text/javascript">
//<![CDATA[
var CUSTOMMENU_POPUP_EFFECT = <?php echo $_smarty_tpl->tpl_vars['effect']->value;?>
;
var CUSTOMMENU_POPUP_TOP_OFFSET = <?php echo $_smarty_tpl->tpl_vars['top_offset']->value;?>
;
//]]>
</script>
<script>
	jQuery(document).ready(function () {
	    jQuery('.mobile-menu nav').meanmenu({
			meanScreenWidth: "767",
			meanMenuContainer: 'body .navmenu-mobile'
		});
	});
</script><?php }} ?>
