<?php /* Smarty version Smarty-3.1.19, created on 2015-09-02 22:08:40
         compiled from "E:\soheil\web_site_root\prestashop\lab_bozon3\modules\labcompare\views\templates\hook\labcompare-extra.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2912755e7342090f133-18255076%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1731c394aeada220e9c647a81d5f612b05af00e5' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\lab_bozon3\\modules\\labcompare\\views\\templates\\hook\\labcompare-extra.tpl',
      1 => 1434994228,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2912755e7342090f133-18255076',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'comparator_max_item' => 0,
    'compareProducts' => 0,
    'product' => 0,
    'product_cover' => 0,
    'link' => 0,
    'product_link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e73420af4840_00824802',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e73420af4840_00824802')) {function content_55e73420af4840_00824802($_smarty_tpl) {?>

<?php if (isset($_smarty_tpl->tpl_vars['comparator_max_item']->value)&&$_smarty_tpl->tpl_vars['comparator_max_item']->value) {?>
    <div class="buttons_bottom_block">
        <a href="javascript:;" class="add_to_compare compare_button <?php if (isset($_smarty_tpl->tpl_vars['compareProducts']->value)&&in_array($_smarty_tpl->tpl_vars['product']->value->id,$_smarty_tpl->tpl_vars['compareProducts']->value)) {?>active<?php }?>" rel="nofollow" title="<?php echo smartyTranslate(array('s'=>'Add to compare','mod'=>'labcompare'),$_smarty_tpl);?>
" data-product-id="<?php echo intval($_smarty_tpl->tpl_vars['product']->value->id);?>
" data-product-name="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['product']->value->name, ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" data-product-cover="<?php echo $_smarty_tpl->tpl_vars['link']->value->getImageLink($_smarty_tpl->tpl_vars['product']->value->link_rewrite,$_smarty_tpl->tpl_vars['product_cover']->value,'medium_default');?>
"  data-product-link="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->tpl_vars['product_link']->value, ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
" ><i class="icon-retweet"></i><span><?php echo smartyTranslate(array('s'=>'Add to compare','mod'=>'labcompare'),$_smarty_tpl);?>
</span></a>
    </div>
<?php }?><?php }} ?>
