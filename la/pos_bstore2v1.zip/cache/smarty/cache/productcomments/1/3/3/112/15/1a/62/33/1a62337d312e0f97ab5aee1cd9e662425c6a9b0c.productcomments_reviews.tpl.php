<?php /*%%SmartyHeaderCode:1447155e8ad13bca178-19707805%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a62337d312e0f97ab5aee1cd9e662425c6a9b0c' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\productcomments\\productcomments_reviews.tpl',
      1 => 1433218420,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1447155e8ad13bca178-19707805',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8c446d81796_86591270',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8c446d81796_86591270')) {function content_55e8c446d81796_86591270($_smarty_tpl) {?>	<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "0" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">0</span> نقد(ها)</span>
	</div>
<?php }} ?>
