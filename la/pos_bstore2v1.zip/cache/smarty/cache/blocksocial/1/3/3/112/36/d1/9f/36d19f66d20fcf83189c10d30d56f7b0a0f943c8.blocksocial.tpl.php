<?php /*%%SmartyHeaderCode:1824255e8ab25bb03f1-22488186%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '36d19f66d20fcf83189c10d30d56f7b0a0f943c8' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1433474303,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1824255e8ab25bb03f1-22488186',
  'variables' => 
  array (
    'facebook_url' => 0,
    'twitter_url' => 0,
    'rss_url' => 0,
    'youtube_url' => 0,
    'google_plus_url' => 0,
    'pinterest_url' => 0,
    'vimeo_url' => 0,
    'instagram_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ab2613f3d9_67899335',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ab2613f3d9_67899335')) {function content_55e8ab2613f3d9_67899335($_smarty_tpl) {?><section id="social_block">
	<h3>ما را دنبال کنید</h3>
						<a class="_blank" href="http://www.facebook.com/prestashop">
					<i class="icon-facebook"></i>
				</a>
								<a class="_blank" href="http://www.twitter.com/prestashop">
					<i class="icon-twitter"></i>
				</a>
								<a class="_blank" href="http://www.prestashop.com/blog/en/">
					<i class="icon-rss"></i>
				</a>
		                        		<a class="_blank" href="https://www.google.com/+prestashop">
        			<i class="icon-google-plus"></i>
        		</a>
                                </section>
<div class="clearfix"></div>
<?php }} ?>
