<?php /*%%SmartyHeaderCode:2477455e8ad138e48d2-95655473%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6da86831223238aec85288e2d5a16f9e61011b4f' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\productscategory\\productscategory.tpl',
      1 => 1434794532,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2477455e8ad138e48d2-95655473',
  'variables' => 
  array (
    'categoryProducts' => 0,
    'categoryProduct' => 0,
    'link' => 0,
    'ProdDisplayPrice' => 0,
    'restricted_country_mode' => 0,
    'PS_CATALOG_MODE' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ad13db5ee3_88952574',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ad13db5ee3_88952574')) {function content_55e8ad13db5ee3_88952574($_smarty_tpl) {?><section class="blockproductscategory">
	<div class="title_block">
			<h3>کالاهای مرتبط</h3>
			<div class="navi">
				<a class="prevtab"><i class="icon-angle-left"></i></a>
				<a class="nexttab"><i class="icon-angle-right"></i></a>
			</div>
		</div>
	<div class="block_content">
		<div class="row">
			<div class="productscategorysld">
							<div class="item">
					<div class="home_tab_img">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html" class="lnk_img product-image" title="نازل کومت">
							<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/66-home_default/faded-short-sleeves-tshirt.jpg" alt="نازل کومت" class="img-responsive"/>
						</a>
					</div>
					<div class="comment_box">
							<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "4" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">1</span> نقد(ها)</span>
	</div>

					</div>
					<h5 itemprop="name" class="product-name">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html" title="نازل کومت">نازل کومت</a>
					</h5>
											<p class="price_display">
													<span class="price">10,000 تومان</span>
												</p>
									</div>
							<div class="item">
					<div class="home_tab_img">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html" class="lnk_img product-image" title="Blouse">
							<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/29-home_default/blouse.jpg" alt="Blouse" class="img-responsive"/>
						</a>
					</div>
					<div class="comment_box">
							<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "5" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">1</span> نقد(ها)</span>
	</div>

					</div>
					<h5 itemprop="name" class="product-name">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html" title="Blouse">Blouse</a>
					</h5>
											<p class="price_display">
						
							<span class="price special-price">23 تومان</span>
							<span class="old-price">27 تومان</span>

												</p>
									</div>
							<div class="item">
					<div class="home_tab_img">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html" class="lnk_img product-image" title="Printed Dress">
							<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/33-home_default/printed-dress.jpg" alt="Printed Dress" class="img-responsive"/>
						</a>
					</div>
					<div class="comment_box">
							<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "3" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">1</span> نقد(ها)</span>
	</div>

					</div>
					<h5 itemprop="name" class="product-name">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html" title="Printed Dress">Printed Dress</a>
					</h5>
											<p class="price_display">
						
							<span class="price special-price">23 تومان</span>
							<span class="old-price">26 تومان</span>

												</p>
									</div>
							<div class="item">
					<div class="home_tab_img">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/evening-dresses/4-printed-dress.html" class="lnk_img product-image" title="Printed Dress">
							<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/36-home_default/printed-dress.jpg" alt="Printed Dress" class="img-responsive"/>
						</a>
					</div>
					<div class="comment_box">
							<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "4" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">2</span> نقد(ها)</span>
	</div>

					</div>
					<h5 itemprop="name" class="product-name">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/evening-dresses/4-printed-dress.html" title="Printed Dress">Printed Dress</a>
					</h5>
											<p class="price_display">
													<span class="price">51 تومان</span>
												</p>
									</div>
							<div class="item">
					<div class="home_tab_img">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/summer-dresses/5-printed-summer-dress.html" class="lnk_img product-image" title="Printed Summer Dress">
							<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/38-home_default/printed-summer-dress.jpg" alt="Printed Summer Dress" class="img-responsive"/>
						</a>
					</div>
					<div class="comment_box">
							<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "3" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">1</span> نقد(ها)</span>
	</div>

					</div>
					<h5 itemprop="name" class="product-name">
						<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/summer-dresses/5-printed-summer-dress.html" title="Printed Summer Dress">Printed Summer Dress</a>
					</h5>
											<p class="price_display">
						
							<span class="price special-price">29 تومان</span>
							<span class="old-price">31 تومان</span>

												</p>
									</div>
						</div>
		</div>
	</div>
</section>
<?php }} ?>
