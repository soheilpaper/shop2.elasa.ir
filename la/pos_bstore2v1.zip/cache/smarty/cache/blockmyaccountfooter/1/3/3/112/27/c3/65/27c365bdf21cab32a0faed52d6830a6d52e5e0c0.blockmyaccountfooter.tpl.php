<?php /*%%SmartyHeaderCode:862355e8ab273a09d4-66146068%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '27c365bdf21cab32a0faed52d6830a6d52e5e0c0' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blockmyaccountfooter\\blockmyaccountfooter.tpl',
      1 => 1440958033,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '862355e8ab273a09d4-66146068',
  'variables' => 
  array (
    'link' => 0,
    'returnAllowed' => 0,
    'voucherAllowed' => 0,
    'HOOK_BLOCK_MY_ACCOUNT' => 0,
    'is_logged' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ab277e9a12_97156470',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ab277e9a12_97156470')) {function content_55e8ab277e9a12_97156470($_smarty_tpl) {?>
<!-- Block myaccount module -->
<section class="footer-block col-xs-12 col-sm-4" style="position: absolute; top: -1%;right: 50%">
	<h4><a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/my-account" title="مدیریت حساب کاربری شما" rel="nofollow">حساب کاربری</a></h4>
	<div class="block_content toggle-footer">
		<ul class="bullet">
			<li><a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/order-history" title="سفارشات من" rel="nofollow">سفارشات من</a></li>
						<li><a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/credit-slip" title="صورت های مالی من" rel="nofollow">صورت های مالی من</a></li>
			<li><a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/addresses" title="آدرس های من" rel="nofollow">آدرس های من</a></li>
			<li><a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/identity" title="مدیریت اطلاعات شخصی شما" rel="nofollow">اطلاعات شخصی شما</a></li>
						
            <li><a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/?mylogout" title="خروج از حساب" rel="nofollow">خروج از حساب</a></li>		</ul>
	</div>
</section>
<!-- /Block myaccount module -->
<?php }} ?>
