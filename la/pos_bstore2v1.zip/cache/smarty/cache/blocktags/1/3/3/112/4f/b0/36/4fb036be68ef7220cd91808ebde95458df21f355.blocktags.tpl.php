<?php /*%%SmartyHeaderCode:579355e8ad135482e3-12892699%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4fb036be68ef7220cd91808ebde95458df21f355' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blocktags\\blocktags.tpl',
      1 => 1432867434,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '579355e8ad135482e3-12892699',
  'variables' => 
  array (
    'tags' => 0,
    'tag' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ad136a7f39_06202815',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ad136a7f39_06202815')) {function content_55e8ad136a7f39_06202815($_smarty_tpl) {?>
<!-- Block tags module -->
<div id="tags_block_left" class="block tags_block">
	<p class="title_block">
		برچسب‌ها
	</p>
	<div class="block_content">
									<a 
				class="tag_level1 last_item"
				href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/search?tag=%D9%86%D8%A7%D8%B2%D9%84" 
				title="بیشتر درباره نازل" 
				>
					نازل
				</a>
						</div>
</div>
<!-- /Block tags module -->
<?php }} ?>
