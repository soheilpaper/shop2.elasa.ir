<?php /*%%SmartyHeaderCode:39355e8ab2658a188-46602646%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '500d57132875c6054691aaf05349bc66e9647639' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blockcategories\\blockcategories_footer.tpl',
      1 => 1434622290,
      2 => 'file',
    ),
    '88f1c8840fe2990f44e1ac371a1433431c44faa0' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1434622290,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '39355e8ab2658a188-46602646',
  'variables' => 
  array (
    'widthColumn' => 0,
    'isDhtml' => 0,
    'blockCategTree' => 0,
    'child' => 0,
    'numberColumn' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ab26848be5_09625505',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ab26848be5_09625505')) {function content_55e8ab26848be5_09625505($_smarty_tpl) {?>
<div class="blockcategories_footer">
<!-- Block categories module -->
	<h4 class="title_block">شاخه‌ها</h4>
<div class="category_footer" style="float:left;clear:none;width:100%">
	<div style="float:left" class="list">
		<ul class="tree dhtml">
	
									
<li class="category_3">
	<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/3-nazzle" 		title="تقسیم بندی انواع نازل مخصوص آبنما  
 این دسته بندی انواع نازل های آبنما را شامل می گردد">نازل آبنما</a>
	</li>

					
													
<li class="category_12">
	<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/12-fountain-watter-pump" 		title="انواع واتر پمپ های آبنما">واتر پمپ آبنما</a>
			<ul>
									
<li class="category_27 last">
	<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/27-santrifiuj" 		title="">پمپ سانتری فیوژ</a>
	</li>

							</ul>
	</li>

					
													
<li class="category_13">
	<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/13--led" 		title="انواع پروژکتور های LED منایب برای پارک ها">پروژکتور LED</a>
	</li>

					
													
<li class="category_26 last">
	<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/26-lamps" 		title="تجهیزات نورپردازی از قبیل منابع تغذیه مناسب و لامپ ها">نورپردازی </a>
	</li>

					
								</ul>
	</div>
</div>
<br class="clear"/>
<!-- /Block categories module -->
</div>
<?php }} ?>
