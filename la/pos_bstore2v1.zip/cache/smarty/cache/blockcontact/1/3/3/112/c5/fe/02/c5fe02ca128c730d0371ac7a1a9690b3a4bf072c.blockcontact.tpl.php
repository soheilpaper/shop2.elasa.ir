<?php /*%%SmartyHeaderCode:3009255e8ab23a08d25-25097815%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c5fe02ca128c730d0371ac7a1a9690b3a4bf072c' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blockcontact\\blockcontact.tpl',
      1 => 1434941837,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3009255e8ab23a08d25-25097815',
  'variables' => 
  array (
    'telnumber' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ab23a87660_22282997',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ab23a87660_22282997')) {function content_55e8ab23a87660_22282997($_smarty_tpl) {?>	<div id="contact_block">
		<h3>تماس با ما</h3>
		<span>989120258354+</span>
	</div>
<?php }} ?>
