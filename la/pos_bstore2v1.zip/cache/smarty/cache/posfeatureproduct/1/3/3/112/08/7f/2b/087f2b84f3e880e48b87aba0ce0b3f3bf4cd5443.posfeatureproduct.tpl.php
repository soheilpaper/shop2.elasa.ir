<?php /*%%SmartyHeaderCode:554555e8c44c8d7b33-97832900%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '087f2b84f3e880e48b87aba0ce0b3f3bf4cd5443' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\posfeatureproduct\\posfeatureproduct.tpl',
      1 => 1440832517,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '554555e8c44c8d7b33-97832900',
  'variables' => 
  array (
    'products' => 0,
    'product' => 0,
    'link' => 0,
    'PS_CATALOG_MODE' => 0,
    'add_prod_display' => 0,
    'restricted_country_mode' => 0,
    'static_token' => 0,
    'priceDisplay' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8c44d4ed0c2_45442475',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8c44d4ed0c2_45442475')) {function content_55e8c44d4ed0c2_45442475($_smarty_tpl) {?>	<div class="col-xs-12">
	<div class="pos_featured_product">
		<div class="title_block">
			<h3>کالاهای ویژه</h3>
			<div class="navi">
				<a class="prevtab"><i class="icon-angle-left"></i></a>
				<a class="nexttab"><i class="icon-angle-right"></i></a>
			</div>
		</div>
		<div class="block_content">
		<div class="row">
			<div class="featuredSlide">
															<div class="item_out">
											<div class="item">
							<div class="home_tab_img">
								<a class="product_img_link"	href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html" title="نازل کومت" itemprop="url">
									<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/66-large_default/faded-short-sleeves-tshirt.jpg"
									alt=""
									class="img-responsive"/>
								</a>
																	<a class="new-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html">
										<span class="new-label">جدید</span>
									</a>
																									<a class="sale-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html">
										<span class="sale-label">حراج!</span>
									</a>
																<div class="btn_content">
										<a 	title="نگاه کوتاه"
											class="quick-view"
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html"
											rel="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html">
											<i class="icon-search"></i>
										</a>
																																														<a class="exclusive ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/cart?add=1&amp;id_product=1&amp;token=0bdea1f17bc1fd29a324fd7d384e9b45" rel="nofollow" title="افزودن به سبد خرید" data-id-product="1">
														<i class="icon-shopping-cart"></i>
													</a>
																																											<a class="add_to_compare" 
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html" 
											title="افزودن به لیست مقایسه"
											data-id-product="1">
											<i class="icon-retweet"></i>
										</a>
										<a 	title="افزودن به علاقه مندی ها"
											class="addToWishlist wishlistProd_1"
											href="#"
											onclick="WishlistCart('wishlist_block_list', 'add', '1', false, 1); return false;">
											<i class="icon-heart-o"></i>
										</a>
								</div>
							</div>
							<div class="home_tab_info">
								<div class="comment_box">
										<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "4" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">1</span> نقد(ها)</span>
	</div>

								</div>
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/1-faded-short-sleeves-tshirt.html" title="&#1606;&#1575;&#1586;&#1604; &#1705;&#1608;&#1605;&#1578;">
									&#1606;&#1575;&#1586;&#1604; &#1705;&#1608;&#1605;&#1578;
								</a>
								<div class="price-box">
									<meta itemprop="priceCurrency" content="1" />
									<span class="price">10,000 تومان</span>
																	</div>
							</div>
						</div>
											</div>
																				<div class="item_out">
											<div class="item">
							<div class="home_tab_img">
								<a class="product_img_link"	href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html" title="Blouse" itemprop="url">
									<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/29-large_default/blouse.jpg"
									alt=""
									class="img-responsive"/>
								</a>
																	<a class="new-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html">
										<span class="new-label">جدید</span>
									</a>
																									<a class="sale-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html">
										<span class="sale-label">حراج!</span>
									</a>
																<div class="btn_content">
										<a 	title="نگاه کوتاه"
											class="quick-view"
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html"
											rel="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html">
											<i class="icon-search"></i>
										</a>
																																														<a class="exclusive ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/cart?add=1&amp;id_product=2&amp;token=0bdea1f17bc1fd29a324fd7d384e9b45" rel="nofollow" title="افزودن به سبد خرید" data-id-product="2">
														<i class="icon-shopping-cart"></i>
													</a>
																																											<a class="add_to_compare" 
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html" 
											title="افزودن به لیست مقایسه"
											data-id-product="2">
											<i class="icon-retweet"></i>
										</a>
										<a 	title="افزودن به علاقه مندی ها"
											class="addToWishlist wishlistProd_2"
											href="#"
											onclick="WishlistCart('wishlist_block_list', 'add', '2', false, 1); return false;">
											<i class="icon-heart-o"></i>
										</a>
								</div>
							</div>
							<div class="home_tab_info">
								<div class="comment_box">
										<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "5" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">1</span> نقد(ها)</span>
	</div>

								</div>
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/blouses/2-blouse.html" title="Blouse">
									Blouse
								</a>
								<div class="price-box">
									<meta itemprop="priceCurrency" content="1" />
									<span class="price">23 تومان</span>
																			<span class="old-price product-price">
											27 تومان
										</span>
																	</div>
							</div>
						</div>
											</div>
																				<div class="item_out">
											<div class="item">
							<div class="home_tab_img">
								<a class="product_img_link"	href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html" title="Printed Dress" itemprop="url">
									<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/33-large_default/printed-dress.jpg"
									alt=""
									class="img-responsive"/>
								</a>
																	<a class="new-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html">
										<span class="new-label">جدید</span>
									</a>
																									<a class="sale-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html">
										<span class="sale-label">حراج!</span>
									</a>
																<div class="btn_content">
										<a 	title="نگاه کوتاه"
											class="quick-view"
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html"
											rel="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html">
											<i class="icon-search"></i>
										</a>
																																														<a class="exclusive ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/cart?add=1&amp;id_product=3&amp;token=0bdea1f17bc1fd29a324fd7d384e9b45" rel="nofollow" title="افزودن به سبد خرید" data-id-product="3">
														<i class="icon-shopping-cart"></i>
													</a>
																																											<a class="add_to_compare" 
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html" 
											title="افزودن به لیست مقایسه"
											data-id-product="3">
											<i class="icon-retweet"></i>
										</a>
										<a 	title="افزودن به علاقه مندی ها"
											class="addToWishlist wishlistProd_3"
											href="#"
											onclick="WishlistCart('wishlist_block_list', 'add', '3', false, 1); return false;">
											<i class="icon-heart-o"></i>
										</a>
								</div>
							</div>
							<div class="home_tab_info">
								<div class="comment_box">
										<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "3" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">1</span> نقد(ها)</span>
	</div>

								</div>
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html" title="Printed Dress">
									Printed Dress
								</a>
								<div class="price-box">
									<meta itemprop="priceCurrency" content="1" />
									<span class="price">23 تومان</span>
																			<span class="old-price product-price">
											26 تومان
										</span>
																	</div>
							</div>
						</div>
											</div>
																				<div class="item_out">
											<div class="item">
							<div class="home_tab_img">
								<a class="product_img_link"	href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/evening-dresses/4-printed-dress.html" title="Printed Dress" itemprop="url">
									<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/36-large_default/printed-dress.jpg"
									alt=""
									class="img-responsive"/>
								</a>
																	<a class="new-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/evening-dresses/4-printed-dress.html">
										<span class="new-label">جدید</span>
									</a>
																								<div class="btn_content">
										<a 	title="نگاه کوتاه"
											class="quick-view"
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/evening-dresses/4-printed-dress.html"
											rel="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/evening-dresses/4-printed-dress.html">
											<i class="icon-search"></i>
										</a>
																																														<a class="exclusive ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/cart?add=1&amp;id_product=4&amp;token=0bdea1f17bc1fd29a324fd7d384e9b45" rel="nofollow" title="افزودن به سبد خرید" data-id-product="4">
														<i class="icon-shopping-cart"></i>
													</a>
																																											<a class="add_to_compare" 
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/evening-dresses/4-printed-dress.html" 
											title="افزودن به لیست مقایسه"
											data-id-product="4">
											<i class="icon-retweet"></i>
										</a>
										<a 	title="افزودن به علاقه مندی ها"
											class="addToWishlist wishlistProd_4"
											href="#"
											onclick="WishlistCart('wishlist_block_list', 'add', '4', false, 1); return false;">
											<i class="icon-heart-o"></i>
										</a>
								</div>
							</div>
							<div class="home_tab_info">
								<div class="comment_box">
										<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "4" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">2</span> نقد(ها)</span>
	</div>

								</div>
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/evening-dresses/4-printed-dress.html" title="Printed Dress">
									Printed Dress
								</a>
								<div class="price-box">
									<meta itemprop="priceCurrency" content="1" />
									<span class="price">51 تومان</span>
																	</div>
							</div>
						</div>
											</div>
																				<div class="item_out">
											<div class="item">
							<div class="home_tab_img">
								<a class="product_img_link"	href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/summer-dresses/5-printed-summer-dress.html" title="Printed Summer Dress" itemprop="url">
									<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/38-large_default/printed-summer-dress.jpg"
									alt=""
									class="img-responsive"/>
								</a>
																	<a class="new-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/summer-dresses/5-printed-summer-dress.html">
										<span class="new-label">جدید</span>
									</a>
																								<div class="btn_content">
										<a 	title="نگاه کوتاه"
											class="quick-view"
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/summer-dresses/5-printed-summer-dress.html"
											rel="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/summer-dresses/5-printed-summer-dress.html">
											<i class="icon-search"></i>
										</a>
																																														<a class="exclusive ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/cart?add=1&amp;id_product=5&amp;token=0bdea1f17bc1fd29a324fd7d384e9b45" rel="nofollow" title="افزودن به سبد خرید" data-id-product="5">
														<i class="icon-shopping-cart"></i>
													</a>
																																											<a class="add_to_compare" 
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/summer-dresses/5-printed-summer-dress.html" 
											title="افزودن به لیست مقایسه"
											data-id-product="5">
											<i class="icon-retweet"></i>
										</a>
										<a 	title="افزودن به علاقه مندی ها"
											class="addToWishlist wishlistProd_5"
											href="#"
											onclick="WishlistCart('wishlist_block_list', 'add', '5', false, 1); return false;">
											<i class="icon-heart-o"></i>
										</a>
								</div>
							</div>
							<div class="home_tab_info">
								<div class="comment_box">
										<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star star_on"></div>
																<div class="star"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "3" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">1</span> نقد(ها)</span>
	</div>

								</div>
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/summer-dresses/5-printed-summer-dress.html" title="Printed Summer Dress">
									Printed Summer Dress
								</a>
								<div class="price-box">
									<meta itemprop="priceCurrency" content="1" />
									<span class="price">29 تومان</span>
																			<span class="old-price product-price">
											31 تومان
										</span>
																	</div>
							</div>
						</div>
											</div>
																				<div class="item_out">
											<div class="item">
							<div class="home_tab_img">
								<a class="product_img_link"	href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/15-theme.html" title="ماژول zopim  مناسب پرستاشاپ" itemprop="url">
									<img src="http://127.0.0.1:8888/prestashop/pos_bstore2/73-large_default/theme.jpg"
									alt="تم"
									class="img-responsive"/>
								</a>
																	<a class="new-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/15-theme.html">
										<span class="new-label">جدید</span>
									</a>
																									<a class="sale-box" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/15-theme.html">
										<span class="sale-label">حراج!</span>
									</a>
																<div class="btn_content">
										<a 	title="نگاه کوتاه"
											class="quick-view"
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/15-theme.html"
											rel="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/15-theme.html">
											<i class="icon-search"></i>
										</a>
																																														<a class="exclusive ajax_add_to_cart_button btn btn-default" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/cart?add=1&amp;id_product=15&amp;token=0bdea1f17bc1fd29a324fd7d384e9b45" rel="nofollow" title="افزودن به سبد خرید" data-id-product="15">
														<i class="icon-shopping-cart"></i>
													</a>
																																											<a class="add_to_compare" 
											href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/15-theme.html" 
											title="افزودن به لیست مقایسه"
											data-id-product="15">
											<i class="icon-retweet"></i>
										</a>
										<a 	title="افزودن به علاقه مندی ها"
											class="addToWishlist wishlistProd_15"
											href="#"
											onclick="WishlistCart('wishlist_block_list', 'add', '15', false, 1); return false;">
											<i class="icon-heart-o"></i>
										</a>
								</div>
							</div>
							<div class="home_tab_info">
								<div class="comment_box">
										<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "0" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">0</span> نقد(ها)</span>
	</div>

								</div>
								<a class="product-name" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/home/15-theme.html" title="&#1605;&#1575;&#1688;&#1608;&#1604; zopim  &#1605;&#1606;&#1575;&#1587;&#1576; &#1662;&#1585;&#1587;&#1578;&#1575;&#1588;&#1575;&#1662;">
									&#1605;&#1575;&#1688;&#1608;&#1604; zopim  &#1605;&#1606;&#1575;&#1587;&#1576; &#1662;&#1585;&#1587;&#1578;&#1575;&#1588;&#1575;&#1662;
								</a>
								<div class="price-box">
									<meta itemprop="priceCurrency" content="1" />
									<span class="price">5,000 تومان</span>
																	</div>
							</div>
						</div>
											</div>
												</div>
		</div>
		</div>
	</div>
	</div>
	<script>
		$(document).ready(function() {
			var featuredSlide = $(".featuredSlide");
			featuredSlide.owlCarousel({
				items : 5,
				itemsDesktop : [1199,4],
				itemsDesktopSmall : [991,3],
				itemsTablet: [767,2],
				itemsMobile : [480,1],
				autoPlay :  false,
				stopOnHover: false,
			});

			// Custom Navigation Events
			$(".pos_featured_product .nexttab").click(function(){
				featuredSlide.trigger('owl.next');})
			$(".pos_featured_product .prevtab").click(function(){
				featuredSlide.trigger('owl.prev');})
		});
	</script>
<?php }} ?>
