<?php /*%%SmartyHeaderCode:125855e8ab23e072f3-56957918%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '87d347b2e48e1b6f70f671e3f6edaa1bc0d3af33' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\possearchcategories\\possearch-top.tpl',
      1 => 1440855069,
      2 => 'file',
    ),
    '2271afac7fd6fe985ce5e1f6515fe83143afa476' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\possearchcategories\\possearch-instantsearch.tpl',
      1 => 1403288000,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '125855e8ab23e072f3-56957918',
  'variables' => 
  array (
    'link' => 0,
    'cate_on' => 0,
    'categories_option' => 0,
    'search_query' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ab242e3da8_99660307',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ab242e3da8_99660307')) {function content_55e8ab242e3da8_99660307($_smarty_tpl) {?>
<!-- pos search module TOP -->
<div id="pos_search_top" class="wrap_seach list-inline">
	<form method="get" action="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/search" id="searchbox" class="form-inline form_search" role="form">
		<label for="pos_query_top"><!-- image on background --></label>
        <input type="hidden" name="controller" value="search" />
        <input type="hidden" name="orderby" value="position" />
        <input type="hidden" name="orderway" value="desc" />
			<div class="pos_search form-group">
                                    <select name="poscats" class="selectpicker">
					 <option value="">شاخه ها</option>
                        <option value="3">--نازل آبنما </option><option value="12">--واتر پمپ آبنما </option><option value="27">---پمپ سانتری فیوژ </option><option value="13">--پروژکتور LED </option><option value="26">--نورپردازی  </option>
                    </select>
                            </div>
			<input class="search_query form-control" type="text" placeholder="کلمات مورد جستجو را اینجا وارد نمایید" id="pos_query_top" name="search_query" value="" />
			<button type="submit" name="submit_search" value="جستجو" class="btn btn-default submit_search">
				<i class="icon-search"></i>
			</button>
    </form>
</div>
	<script type="text/javascript">
	// <![CDATA[
		$('document').ready( function() {
			$("#pos_query_top")
				.autocomplete(
					'http://127.0.0.1:8888/prestashop/pos_bstore2/fa/search', {
                        minChars: 3,
						max: 10,
						width: 500,
						selectFirst: false,
                        loadingClass: "ac_loading",
                        inputClass: "ac_input",
						scroll: false,
						dataType: "json",
						formatItem: function(data, i, max, value, term) {
							return value;
						},
						parse: function(data) {
							var mytab = new Array();
							for (var i = 0; i < data.length; i++)
								mytab[mytab.length] = {  data: data[i], value: data[i].cname + ' > ' + data[i].pname };
							return mytab;
						},
						extraParams: {
							ajaxSearch:1,
							id_lang: 3
						}
					}
				)
				.result(function(event, data, formatted) {
					$('#pos_query_top').val(data.pname);
					document.location.href = data.product_link;
				})
		});
	</script>



<script type="text/javascript">
    $(window).on('load', function () {

        $('.selectpicker').selectpicker({
            'selectedText': 'cat'
        });

        // $('.selectpicker').selectpicker('hide');
    });
</script>
<!-- /pos search module TOP -->
<?php }} ?>
