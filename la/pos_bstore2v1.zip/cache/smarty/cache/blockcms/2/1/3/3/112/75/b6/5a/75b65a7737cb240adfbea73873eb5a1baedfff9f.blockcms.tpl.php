<?php /*%%SmartyHeaderCode:551855e8ab268a7928-97081695%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '75b65a7737cb240adfbea73873eb5a1baedfff9f' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blockcms\\blockcms.tpl',
      1 => 1434940160,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '551855e8ab268a7928-97081695',
  'variables' => 
  array (
    'block' => 0,
    'cms_titles' => 0,
    'cms_key' => 0,
    'cms_title' => 0,
    'cms_page' => 0,
    'link' => 0,
    'show_price_drop' => 0,
    'PS_CATALOG_MODE' => 0,
    'show_new_products' => 0,
    'show_best_sales' => 0,
    'display_stores_footer' => 0,
    'show_contact' => 0,
    'contact_url' => 0,
    'cmslinks' => 0,
    'cmslink' => 0,
    'show_sitemap' => 0,
    'footer_text' => 0,
    'display_poweredby' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ab27362ef3_08427728',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ab27362ef3_08427728')) {function content_55e8ab27362ef3_08427728($_smarty_tpl) {?>
	<!-- MODULE Block footer -->
	<section class="footer-block col-xs-12 col-sm-4" id="block_various_links_footer">
		<h4>اطلاعات</h4>
		<ul class="toggle-footer">
							<li class="item">
					<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/prices-drop" title="محصولات ویژه">
						محصولات ویژه
					</a>
				</li>
									<li class="item">
				<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/new-products" title="محصولات جدید">
					محصولات جدید
				</a>
			</li>
										<li class="item">
					<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/best-sales" title="پرفروش ترین‌ ها">
						پرفروش ترین‌ ها
					</a>
				</li>
												<li class="item">
				<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/contact-us" title="تماس با ما">
					تماس با ما
				</a>
			</li>
											</ul>
		
	</section>
		<div class="bottom-footer col-xs-12 hidden">
		<div>
			&copy; 2014 <a class="_blank" href="http://www.prestashop.com">نرم افزار تجارت الکترونیک توسط PrestaShop™</a>
		</div>
	</div>
		<!-- /MODULE Block footer -->
<?php }} ?>
