<?php /*%%SmartyHeaderCode:3170955e8ad14142bd4-42229343%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd37fe637b06169ff9d71b84b13f4ae2fa7831a0b' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\socialsharing\\views\\templates\\hook\\socialsharing.tpl',
      1 => 1434622361,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3170955e8ad14142bd4-42229343',
  'variables' => 
  array (
    'PS_SC_TWITTER' => 0,
    'PS_SC_FACEBOOK' => 0,
    'PS_SC_GOOGLE' => 0,
    'PS_SC_PINTEREST' => 0,
    'module_dir' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ad14311558_44124485',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ad14311558_44124485')) {function content_55e8ad14311558_44124485($_smarty_tpl) {?>
	<p class="socialsharing_product list-inline no-print">
									<button data-type="google-plus" type="button" class="btn btn-default btn-google-plus social-sharing">
				<i class="icon-google-plus"></i> گوگل+
				<!-- <img src="http://127.0.0.1:8888/prestashop/pos_bstore2/modules/socialsharing/img/google.gif" alt="Google Plus" /> -->
			</button>
							<button data-type="pinterest" type="button" class="btn btn-default btn-pinterest social-sharing">
				<i class="icon-pinterest"></i> پینترست
				<!-- <img src="http://127.0.0.1:8888/prestashop/pos_bstore2/modules/socialsharing/img/pinterest.gif" alt="Pinterest" /> -->
			</button>
			</p>
<?php }} ?>
