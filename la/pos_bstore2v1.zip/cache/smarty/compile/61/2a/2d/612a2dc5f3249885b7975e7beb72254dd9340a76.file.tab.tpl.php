<?php /* Smarty version Smarty-3.1.19, created on 2015-09-04 00:57:00
         compiled from "E:\soheil\web_site_root\prestashop\pos_bstore2\themes\pos_bstore1\modules\productcomments\\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:182455e8ad148a2085-15365196%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '612a2dc5f3249885b7975e7beb72254dd9340a76' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\productcomments\\\\tab.tpl',
      1 => 1433822313,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '182455e8ad148a2085-15365196',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e8ad148be5b9_00387526',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e8ad148be5b9_00387526')) {function content_55e8ad148be5b9_00387526($_smarty_tpl) {?>

<li><a href="#idTab5" class="idTabHrefShort page-product-heading"><?php echo smartyTranslate(array('s'=>'Reviews','mod'=>'productcomments'),$_smarty_tpl);?>
</a></li><?php }} ?>
