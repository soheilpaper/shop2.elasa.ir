<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_ee653ade5f520037ef95e9dc2a42364c'] = 'روند داشبورد';
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_2d125dc25b158f28a1960bd96a9fa8d1'] = '%s نکته ها';
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'فروش‌ها';
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_7442e29d7d53e549b78d93c46b8cdcfc'] = 'سفارش‌ها';
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_8c804960da61b637c548c951652b0cac'] = 'سبد خرید متوسط';
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_d7e637a6e9ff116de2fa89551240a94d'] = 'بازدیدها';
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_e4c3da18c66c0147144767efeb59198f'] = 'نرخ تبدیل';
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_43d729c7b81bfa5fc10e756660d877d1'] = 'سود خالص';
$_MODULE['<{dashtrends}pos_bstore1>dashtrends_46418a037045b91e6715c4da91a2a269'] = '%s (دوره قبلی)';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_2938c7f7e560ed972f8a4f68e80ff834'] = 'پیشخوان';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'پیکربندی';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'تازه سازی';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_e537825dd409a90ef70d8c2eb56122a1'] = 'جمع درآمد (بدون مالیات) ایجاد شده در محدوده‌ی تاریخ با سفارش‌های معتبر در نظر گرفته.';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'فروش‌ها';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_8bc1c5ca521b99b87908db0bcd33ec76'] = 'جمع تعداد سفارش های گرفته شده در محدوده‌ی تاریخ به وسیله‌ی سفارش‌های معتبر در نظر گرفته.';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_7442e29d7d53e549b78d93c46b8cdcfc'] = 'سفارش‌ها';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_f15f2a2bf99d3dcad2cba1a2c615b9dc'] = 'میانگین ارزش سبد خرید یک معیار بیانگر سنجش متوسط سفارش در محدوده‌ی تاریخ است. این مقدار به وسیله‌ی فروش‌ها براساس سفارش‌ها محاسبه شده است.';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_791d6355d34dfaf60d68ef04d1ee5767'] = 'ارزش سبد خرید';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_4f631447981c5fa240006a5ae2c4b267'] = 'جمع تعداد بازدیدها در محدوده‌ی تاریخ. یک بازدید دوره ای از زمان یک کاربر که در وب سایت شما مشغول بوده است، می‌باشد.';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_d7e637a6e9ff116de2fa89551240a94d'] = 'بازدیدها';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_7a6e858f8c7c0b78fb4d43cefcb8c017'] = 'نرخ تبدیل تجارت الکترونیک درصدی از بازدیدهاست که در نتیجه‌ی یک سفارش معتبر می‌باشد.';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_e4c3da18c66c0147144767efeb59198f'] = 'نرخ تبدیل';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_8dedc1b3ee3a92212fb5b5acad7f207f'] = 'سود خالص یک اندازه گیری سوددهی ریسک بعد از حسابرسی برای همه‌ی هزینه‌های تجارت الکترونیک است. شما می‌توانید این هزینه‌ها را به وسیله‌ی کلیک روی آیکون پیکربندی درست در زیر این جا، فراهم کنید.';
$_MODULE['<{dashtrends}pos_bstore1>dashboard_zone_two_43d729c7b81bfa5fc10e756660d877d1'] = 'سود خالص';
