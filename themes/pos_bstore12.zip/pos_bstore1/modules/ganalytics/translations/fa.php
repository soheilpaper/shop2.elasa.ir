<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_d86cf69a8b82547a94ca3f6a307cf9a6'] = 'آنالیز گوگل';
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_135d2522825fa02688ab25a2e1c88c73'] = 'معیارهای مهم واضح در رابطه با مشتریان خود با استفاده از آنالیز گوگل را به دست آورید';
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_7ed5c154078e30b30b2f214299c5e9f5'] = 'برای حذف گوگل آنالیز اطمینان دارید؟ تمامی داده های این ماژول از بین خواهند رفت.';
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_c9cc8cce247e49bae79f15173ce97354'] = 'ذخیره';
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_630f6dc397fe74e52d5189e2c80f282b'] = 'بازگشت به فهرست';
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_f4f70727dc34561dfde1a3c529b6205c'] = 'تنظیمات';
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_851bd83a102d143ee17d97f9e15e15af'] = 'Tracking ID آنالیز گوگل';
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_ad8e83a47926dcb12e8a8fccd7fcf604'] = 'این اطلاعات در حساب آنالیز گوگل شما در دسترس است';
$_MODULE['<{ganalytics}pos_bstore1>ganalytics_462390017ab0938911d2d4e964c0cab7'] = 'تنظیمات با موفقیت به روز رسانی شد';
$_MODULE['<{ganalytics}pos_bstore1>configuration_1f13d86a35be758509f9bdfcce5ec55d'] = 'مشتریان شما همه جا می روند، نباید آن اطلاعات شامل آنالیز شما باشد.';
$_MODULE['<{ganalytics}pos_bstore1>configuration_7063e771c3bb338ba74ac4e4716dbae1'] = 'آنالیز گوگل به شما تصویری کامل از مشتری به واسطه‌ی تبلیغات و ویدئو‌ها، وب سایت ها و ابزارهای اجتماعی، جداول و گوشی ها هوشمند نشان می دهد که ارائه خدمات به مشتریان فعلی شما را آسان تر می کند و شانس بدست آوردن مشتری جدید را بالا می برد.';
$_MODULE['<{ganalytics}pos_bstore1>configuration_df15c5cf264eb769b087f9d81aff029f'] = 'با تجارت الکترونیک در آنالیز گوگل می‌توانید معیار های مهم واضح درباره‌ی رفتار و گفتگوی خریداران به دست آورید، شامل:';
$_MODULE['<{ganalytics}pos_bstore1>configuration_613c191b4a1f82a454b72a840d96eefd'] = 'چشم انداز جزئیات محصول';
$_MODULE['<{ganalytics}pos_bstore1>configuration_d88b192dfe623e2a628a919b99fc1a4b'] = 'موفقیت تجارت داخلی';
$_MODULE['<{ganalytics}pos_bstore1>configuration_ade6a18bb6c147db87bc9463240e455a'] = 'عملیات \"افزودن به سبد خرید\"';
$_MODULE['<{ganalytics}pos_bstore1>configuration_c975b6b93d71b19da73114c4adcedbda'] = 'روند پرداخت';
$_MODULE['<{ganalytics}pos_bstore1>configuration_33f50b54625790316b86485ff3e794c4'] = 'کلیک‌های کمپین داخلی';
$_MODULE['<{ganalytics}pos_bstore1>configuration_89c48ff165eedcc3cd1bd0007115669d'] = 'و خرید';
$_MODULE['<{ganalytics}pos_bstore1>configuration_4632d86a96205013262bcfdd0279b39f'] = 'فروشندگان می‌توانند بفهمند چگونه کاربرها وارد روند خرید می‌شوند و کجا خرید را رها می کنند.';
$_MODULE['<{ganalytics}pos_bstore1>configuration_16fafb5cce24f766bf2c8fcebecf76fc'] = 'برای شروع یک حساب کاربری ایجاد کنید.';
$_MODULE['<{ganalytics}pos_bstore1>form-ps14_c9cc8cce247e49bae79f15173ce97354'] = 'ذخیره';
