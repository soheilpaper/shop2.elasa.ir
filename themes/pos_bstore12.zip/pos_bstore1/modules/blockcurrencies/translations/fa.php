<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcurrencies}pos_bstore1>blockcurrencies_f7a31ae8f776597d4282bd3b1013f08b'] = 'بخش واحد پول';
$_MODULE['<{blockcurrencies}pos_bstore1>blockcurrencies_80ed40ee905b534ee85ce49a54380107'] = 'افزودن یک بخش جهت انتخاب واحدپول.';
$_MODULE['<{blockcurrencies}pos_bstore1>blockcurrencies_386c339d37e737a436499d423a77df0c'] = 'واحد پول';
