<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphnvd3}pos_bstore1>graphnvd3_a9f70dff230e6fc8e878043486e6cddf'] = 'نمودارهای NVD3';
