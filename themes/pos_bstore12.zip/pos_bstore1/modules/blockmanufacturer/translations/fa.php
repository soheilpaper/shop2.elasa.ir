<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'بخش تولیدکننده ها';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'نمایش لیستی از تولیدکننده ها/شرکتها';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_f8c922e47935b3b76a749334045d61cf'] = 'تعداد عناصر معتبر نمی باشد.';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'لطفا حداقل یک سیستم فهرست را فعال کنید.';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_f38f5974cdc23279ffe6d203641a8bdf'] = 'تنظیمات به روز رسانی شدند';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'تنظیمات';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_bfdff752293014f11f17122c92909ad5'] = 'استفاده از لیست متنی';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_a7c6946ecc7f4ed19c2691a1e7a28f97'] = 'نمایش تولیدکننده ها در یک لیست متنی ساده.';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'فعال';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'غیرفعال';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_2eef734f174a02ae3d7aaafefeeedb42'] = 'تعداد المان ها برای نمایش';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_b0fa976774d2acf72f9c62e9ab73de38'] = 'استفاده از لیست پایین رو';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'جهت نمایش تولیدکننده ها در یک لیست پایین رو';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'ذخیره';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'تولید کننده‌ها';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_c70ad5f80e4c6f299013e08cabc980df'] = 'بیشتر درباره %s';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'همه تولیدکننده ها';
$_MODULE['<{blockmanufacturer}pos_bstore1>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'هیچ تولیدکننده ای وجود ندارد';
