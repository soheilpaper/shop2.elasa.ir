<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{poslogo}pos_bstore1>logo_84551d1233033db9e2387af0145b3130'] = 'برند ها و مشتریان';
$_MODULE['<{poslogo}pos_bstore1>logo_8c2857a9ad1d8f31659e35e904e20fa6'] = 'لوگو';
