<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'صفحات ناموجود';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'یک برگه به پیشخوان آمار اضافه میکند، صفحات درخواستی بازدید کنندگان شما را که پیدا نشده است را نشان می دهد.';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'صفحات پیدا نشده، خالی شدند.';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'کش \"صفحه پیدا نشد\" حذف شده است.';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'راهنما';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'خطاهای 404';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_675f1f46497aeeee35832a5d9d095976'] = 'خطای 404 یک کد خطای HTTP است که نشان می‌دهد فایل یا صفحه درخواست شده کاربر وجود ندارد. در این مورد، این خطا نشانگر وارد کردن یک آدرس غیر معتبر توسط کاربر است، یا این که شما یا سایت دیگری یک لینک خراب شده دارید. اگر امکانش فراهم باشد، ابزاری فراخوانده می‌شود که می‌تواند صفحه/سایت محتوی لینک خراب را مشخص کند. اگر این امکان را نداشته باشید، باید بدانید که این خطا به صورت کلی نشان دهنده یک دسترسی مستقیم است که ممکن است کاربر به لیست علاقه مندی‌هایش اضافه کرده باشد، در حالی که آن لینک دیگر موجود نیست.';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'چگونه این خطاها را تشخیص و دریافت کنید؟';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'اگر میزبان وب شما فایل htaccess را پشتیبانی کند، شما می‌توانید آن را در دایرکتوری PrestaShop بسازید و خط زیر را درون آن قرار دهید.  \"%s\".';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'اگر کاربری درخواست صفحه ای را بکند که موجود نیست، به صفحه زیر منتقل خواهد شد:%s. این ماژول دسترسی‌ها به این صفحه را ثبت می‌کند.';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'شما باید از فایل htaccess. برای انتقال خطاهای 404 به صفحه \"404.php\" استفاده کنید.';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'صفحه';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'ارجاع دهنده';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'شمارنده';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'هیچ وضعیت \"صفحه یافت نشد\" تاکنون ثبت نشده است.';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'خالی کردن دیتابیس';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'همه هشدارهای \"صفحه یافت نشد\" را برای این دوره حذف کن';
$_MODULE['<{pagesnotfound}pos_bstore1>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'همه اخطارهای \"صفحه یاف نشد\" را خالی کن';
