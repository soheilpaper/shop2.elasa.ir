<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_5d17bf499a1b9b2e816c99eebf0153a9'] = 'محصولات پرطرفدار در صفحه خانگی';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_6d37ec35b5b6820f90394e5ee49e8cec'] = 'نمایش محصولات پرطرفدار در ستون مرکزی صفحه اصلی.';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_fddb8a1881e39ad11bfe0d0aca5becc3'] = 'تعداد این محصولات نادرست است. لطفا یک مقدار مثبت وارد کنید.';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_c284a59996a4e984b30319999a7feb1d'] = 'شناسه‌ی دسته نادرست است. لطفا از بین شناسه‌های موجود در دسته‌ها، یکی را انتخاب کنید.';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_fd2608d329d90e9a49731393427d0a5a'] = 'مقدار نادرست برای پرچم \"اتفاقی\".';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_6af91e35dff67a43ace060d1d57d5d1a'] = 'تنظیمات به روز رسانی شد';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'تنظیمات';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_abc877135a96e04fc076becb9ce6fdfa'] = 'برا افزوردن محصولات به صفحه‌ی اصلی، به سادگی آن‌ها را به دسته‌ی محصول متناظر اضافه کنید (پیش فرض: \"خانه\").';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_d44168e17d91bac89aab3f38d8a4da8e'] = 'تعداد محصولات برای نمایش';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_1b73f6b70a0fcd38bbc6a6e4b67e3010'] = 'تعداد محصولاتی که در صفحه خانگی نمایش داده می شوند را تنظیم کنید (پیش فرض: 8).';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_b773a38d8c456f7b24506c0e3cd67889'] = 'دسته‌ای که محصولات از آن انتخاب و نمایش داده شده‌اند';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_0db2d53545e2ee088cfb3f45e618ba68'] = 'شناسه‌ی دسته‌ی محصولاتی که می‌خواهید روی صفحه‌ی اصلی به نمایش درآید را انتخاب کنید (پیش فرض: 2 برای \"خانه\").';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_49417670345173e7b95018b7bf976fc7'] = 'نمایش اتفاقی محصولات پیشنهادی';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_3c12c1068fb0e02fe65a6c4fc40bc29a'] = 'فعال کنید اگر می خواهید محصولات به صورت تصادفی نمایش داده شوند (پیش فرض: خیر).';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_93cba07454f06a4a960172bbd6e2a435'] = 'بله';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_bafd7322c6e97d25b6299b5d6fe8920b'] = 'خیر';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'ذخیره';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'محصولات پرطرفدار';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_03c2e7e41ffc181a4e84080b4710e81e'] = 'جدید';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'بیشتر';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'مشاهده';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'افزودن به سبد خرید';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'محصول پرطرفداری وجود ندارد';
$_MODULE['<{homefeatured}pos_bstore1>tab_2cc1943d4c0b46bfcf503a75c44f988b'] = 'محبوب';
$_MODULE['<{homefeatured}pos_bstore1>homefeatured_d505d41279039b9a68b0427af27705c6'] = 'در حال حاضر محصول پرطرفداری وجود ندارد.';
