<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuseronline}pos_bstore1>blockuseronline_f53b749ed54b674b89e3823296734468'] = 'آمار بازدیدکنندگان - ترجمه و تنظیم : Www.PrestaTools.Ir';
$_MODULE['<{blockuseronline}pos_bstore1>blockuseronline_9b3c76275db165d95cf3f621c1d85941'] = 'نمایش آمار لحظه ای از صفحه اول شما';
$_MODULE['<{blockuseronline}pos_bstore1>blockuseronline_e6f4835cedc97b6a09c89b3cf54397d1'] = 'آمار بازدیدکنندگان';
$_MODULE['<{blockuseronline}pos_bstore1>blockuseronline_20d534c8b584685d5f62e03d2da6470d'] = 'افراد آنلاین :';
$_MODULE['<{blockuseronline}pos_bstore1>blockuseronline_44d160a6dea925975a1d2c1dce19d75f'] = 'بازدید امروز :';
$_MODULE['<{blockuseronline}pos_bstore1>blockuseronline_9b0abadc1fba985cac2772b74a9ac0ca'] = 'بازدید کل :';
$_MODULE['<{blockuseronline}pos_bstore1>blockuseronline_5d8d9fe719c2d9c9690fb043ce9f067b'] = 'IP شما :';
