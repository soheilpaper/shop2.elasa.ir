<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'بلوک بنر';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'نمایش بنر در بالای فروشگاه.';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'خطایی در هنگام بارگذاری فایل به وجود آمده است';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'تنظیمات به‌روز شد.';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'تنظیمات';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'تصویر بنر بالا';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'یک تصویر برای بنر بالا آپلود کنید. برای قالب پیشفرض ابعاد پیشفرض 1170*65 پیکسل می باشد.';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_46fae48f998058600248a16100acfb7e'] = 'لینک بنر';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'لینک مرتبط با بنر خود را وارد کنید. وقتی روی بنر کلیک می‌کنید لینک مورد نظر در پنجره‌ی مشابه باز می‌شود. اگر لینکی وارد نشود، به صفحه‌ی اصلی ریدایرکت می‌شود.';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'توضیحات بنر';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'لطفا یک توضیح کوتاه اما معنی دار برای بنر وارد کنید.';
$_MODULE['<{blockbanner}pos_bstore1>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'ذخیره';
