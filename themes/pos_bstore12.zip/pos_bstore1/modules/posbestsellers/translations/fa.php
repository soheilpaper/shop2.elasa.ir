<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{posbestsellers}pos_bstore1>posbestsellers_652b1d8053adf3260419775deced3ff3'] = 'پرفروش ترین ها';
$_MODULE['<{posbestsellers}pos_bstore1>posbestsellers_03c2e7e41ffc181a4e84080b4710e81e'] = 'جدید';
$_MODULE['<{posbestsellers}pos_bstore1>posbestsellers_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'حراج !';
$_MODULE['<{posbestsellers}pos_bstore1>posbestsellers_c91e4ee170226d66e90f99ba917e4c20'] = 'نگاه کوتااه';
$_MODULE['<{posbestsellers}pos_bstore1>posbestsellers_2d0f6b8300be19cf35e89e66f0677f95'] = 'افزودن به سبد خرید ';
$_MODULE['<{posbestsellers}pos_bstore1>posbestsellers_aa1411cc44ecfafbca0d71427fe3dc7a'] = 'افزودن به لیست مقایسه ';
$_MODULE['<{posbestsellers}pos_bstore1>posbestsellers_2d96bb66d8541a89620d3c158ceef42b'] = 'افزودن به علاقه مندی ها';
