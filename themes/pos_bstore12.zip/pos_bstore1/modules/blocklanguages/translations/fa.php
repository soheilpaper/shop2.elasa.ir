<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}pos_bstore1>blocklanguages_d33f69bfa67e20063a8905c923d9cf59'] = 'بلوک انتخاب زبان';
$_MODULE['<{blocklanguages}pos_bstore1>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'افزودن یک بلوک که به مشتریان اجازه میدهد یک زبان برای محتوای فروشگاه شما انتخاب کنند.';
$_MODULE['<{blocklanguages}pos_bstore1>blocklanguages_4994a8ffeba4ac3140beb89e8d41f174'] = 'زبان';
