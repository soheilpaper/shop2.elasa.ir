<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gridhtml}pos_bstore1>gridhtml_cf6b972204ee563b4e5691b293e931b6'] = 'نمایش جداول HTML ساده';
$_MODULE['<{gridhtml}pos_bstore1>gridhtml_05ce5a49b49dd6245f71e384c4b43564'] = 'اجازه می دهد به سیستم آمار برای نمایش داده ها در شبکه .';
