<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}pos_bstore1>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'بخش برچسب ها';
$_MODULE['<{blocktags}pos_bstore1>blocktags_b2de1a21b938fcae9955206a4ca11a12'] = 'افزودن بلوکی شامل برچسب های محصولات شما.';
$_MODULE['<{blocktags}pos_bstore1>blocktags_8d731d453cacf8cff061df22a269b82b'] = 'لطفا فیلد \"برچسب های نمایش داده شده\" را کامل کنید.';
$_MODULE['<{blocktags}pos_bstore1>blocktags_73293a024e644165e9bf48f270af63a0'] = 'تعداد نامعتبر.';
$_MODULE['<{blocktags}pos_bstore1>blocktags_fb3855930920fd1ef34c4904ef230802'] = 'لطفاً فیلد \"سطوح برچسب‌ها\" را کامل کنید.';
$_MODULE['<{blocktags}pos_bstore1>blocktags_feb6da9d1dab0d22293d1da205fa1bb2'] = 'مقدار نادرست برای «سطوح برچسب‌ها». یک عدد صحیح مثبت انتخاب کنید.';
$_MODULE['<{blocktags}pos_bstore1>blocktags_08d5df9c340804cbdd62c0afc6afa784'] = 'لطفاً فیلد «تصادفی» را کامل کنید.';
$_MODULE['<{blocktags}pos_bstore1>blocktags_5c35c840e2d37e5cb3b6e1cf8aa78880'] = 'مقدار نامعتبر برای «تصادفی». می بایست بولین باشد.';
$_MODULE['<{blocktags}pos_bstore1>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'تنظیمات به روز رسانی شد';
$_MODULE['<{blocktags}pos_bstore1>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'تنظیمات';
$_MODULE['<{blocktags}pos_bstore1>blocktags_726cefc6088fc537bc5b18f333357724'] = 'برچسب های نمایش داده شده';
$_MODULE['<{blocktags}pos_bstore1>blocktags_34a51d24608287f9b34807c3004b39d9'] = 'تعداد برچسب‌هایی که می‌خواهید در این بلاک نمایش داده شوند را تنظیم کنید. (پیش فرض: 10)';
$_MODULE['<{blocktags}pos_bstore1>blocktags_ed7a7c842913f44b32b0f06d5a369dcf'] = 'سطوح برچسب‌ها';
$_MODULE['<{blocktags}pos_bstore1>blocktags_d088d9f9a8634d69a2aa0b11883fb6b1'] = 'مقدار سطوح برچسب‌های متفاوتی که می‌خواهید استفاده شوند را تنظیم کنید. (پیش فرض: 3)';
$_MODULE['<{blocktags}pos_bstore1>blocktags_ac5bf3b321fa29adf8af5c825d670e76'] = 'نمایش تصادفی';
$_MODULE['<{blocktags}pos_bstore1>blocktags_d4a9f41f7f8d2a65cda97d8b5eb0c9d5'] = 'اگر فعال شود، برچسب ها به صورت تصادفی نمایش داده خواهد شد. به طور پیش فرض، نمایش تصادفی غیرفعال است و به ترتیب، برچسب های بیشتر استفاده شده نمایش داده می شوند.';
$_MODULE['<{blocktags}pos_bstore1>blocktags_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'فعال';
$_MODULE['<{blocktags}pos_bstore1>blocktags_b9f5c797ebbf55adccdd8539a65a0241'] = 'غیرفعال';
$_MODULE['<{blocktags}pos_bstore1>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'ذخیره';
$_MODULE['<{blocktags}pos_bstore1>blocktags_189f63f277cd73395561651753563065'] = 'برچسب‌ها';
$_MODULE['<{blocktags}pos_bstore1>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'بیشتر درباره';
$_MODULE['<{blocktags}pos_bstore1>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'هنوز برچسبی تعیین نشده است';
$_MODULE['<{blocktags}pos_bstore1>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'هنوز برچسبی تعیین نشده است';
