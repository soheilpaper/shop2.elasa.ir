<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_fc02586aa99596947b184a01f43fb4ae'] = 'بلوک اطلاعات تماس';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_86458ae1631be34a6fcbf1a4584f5abe'] = 'این ماژول به شما اجازه نمایش اطلاعات تماس فروشگاه شما را در یک بلوک سفارشی می دهد.';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'تنظیمات بروز شد';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_f4f70727dc34561dfde1a3c529b6205c'] = 'تنظیمات';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_c281f92b77ba329f692077d23636f5c9'] = 'نام شرکت';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_dd7bf230fde8d4836917806aff6a6b27'] = 'آدرس';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_1f8261d17452a959e013666c5df45e07'] = 'شماره تلفن';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'ایمیل';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_c9cc8cce247e49bae79f15173ce97354'] = 'ذخیره';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'تماس با ما';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_2e006b735fbd916d8ab26978ae6714d4'] = 'تلفن';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_6a1e265f92087bb6dd18194833fe946b'] = 'ایمیل:';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_80a11d2a54a677f6fadd9c041c0d6b98'] = 'اطلاعات فروشگاه';
$_MODULE['<{blockcontactinfos}prestashop>blockcontactinfos_320abee94a07e976991e4df0d4afb319'] = 'هم اکنون با ما تماس بگیرید:';


return $_MODULE;
