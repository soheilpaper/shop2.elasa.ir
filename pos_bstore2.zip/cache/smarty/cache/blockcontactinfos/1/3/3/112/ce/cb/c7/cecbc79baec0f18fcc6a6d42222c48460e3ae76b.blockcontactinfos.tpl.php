<?php /*%%SmartyHeaderCode:2774755e3522334c854-09265636%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cecbc79baec0f18fcc6a6d42222c48460e3ae76b' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blockcontactinfos\\blockcontactinfos.tpl',
      1 => 1432867434,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2774755e3522334c854-09265636',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e36d47cfcca0_07723149',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e36d47cfcca0_07723149')) {function content_55e36d47cfcca0_07723149($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos" class="footer-block col-xs-12 col-sm-4">
	<div>
        <h4>اطلاعات فروشگاه</h4>
        <ul class="toggle-footer">
                        	<li>
            		<i class="icon-map-marker"></i>الکتروآسای بیهق, ایران-خراسان رضوی
سبزوار- قائم 13
پلاک 6            	</li>
                                    	<li>
            		<i class="icon-phone"></i>هم اکنون با ما تماس بگیرید: 
            		<span>989155253009+</span>
            	</li>
                                    	<li>
            		<i class="icon-envelope-alt"></i>ایمیل: 
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%73%6f%68%65%69%6c%5f%70%61%70%65%72@%79%61%68%6f%6f.%63%6f%6d" >&#x73;&#x6f;&#x68;&#x65;&#x69;&#x6c;&#x5f;&#x70;&#x61;&#x70;&#x65;&#x72;&#x40;&#x79;&#x61;&#x68;&#x6f;&#x6f;&#x2e;&#x63;&#x6f;&#x6d;</a></span>
            	</li>
                    </ul>
    </div>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>
