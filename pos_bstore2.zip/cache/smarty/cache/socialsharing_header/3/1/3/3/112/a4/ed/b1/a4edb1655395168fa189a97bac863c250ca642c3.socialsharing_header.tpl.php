<?php /*%%SmartyHeaderCode:1843155e3662e432555-18692142%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a4edb1655395168fa189a97bac863c250ca642c3' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\socialsharing\\views\\templates\\hook\\socialsharing_header.tpl',
      1 => 1434622361,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1843155e3662e432555-18692142',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e3720a690902_09303698',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e3720a690902_09303698')) {function content_55e3720a690902_09303698($_smarty_tpl) {?><meta property="og:type" content="product" /> 
<meta property="og:url" content="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/casual-dresses/3-printed-dress.html" /> 
<meta property="og:title" content="Printed Dress - pos_bstore" /> 
<meta property="og:site_name" content="pos_bstore" />
<meta property="og:description" content="100% cotton double printed dress. Black and white striped top and orange high waisted skater skirt bottom." />
<meta property="og:image" content="http://127.0.0.1:8888/prestashop/pos_bstore2/33-large_default/printed-dress.jpg" />
<meta property="product:pretax_price:amount" content="23.4" /> 
<meta property="product:pretax_price:currency" content="IRT" /> 
<meta property="product:price:amount" content="23.4" /> 
<meta property="product:price:currency" content="IRT" /> 
<?php }} ?>
