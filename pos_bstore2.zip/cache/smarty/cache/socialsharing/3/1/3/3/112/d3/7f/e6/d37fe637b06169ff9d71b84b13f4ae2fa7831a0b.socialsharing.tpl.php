<?php /*%%SmartyHeaderCode:357655e36707b4e3f3-57717372%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd37fe637b06169ff9d71b84b13f4ae2fa7831a0b' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\socialsharing\\views\\templates\\hook\\socialsharing.tpl',
      1 => 1434622361,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '357655e36707b4e3f3-57717372',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e3720af178e4_42172019',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e3720af178e4_42172019')) {function content_55e3720af178e4_42172019($_smarty_tpl) {?>
	<p class="socialsharing_product list-inline no-print">
					<button data-type="twitter" type="button" class="btn btn-default btn-twitter social-sharing">
				<i class="icon-twitter"></i> توییت
				<!-- <img src="http://127.0.0.1:8888/prestashop/pos_bstore2/modules/socialsharing/img/twitter.gif" alt="Tweet" /> -->
			</button>
							<button data-type="facebook" type="button" class="btn btn-default btn-facebook social-sharing">
				<i class="icon-facebook"></i> اشتراک گذاری
				<!-- <img src="http://127.0.0.1:8888/prestashop/pos_bstore2/modules/socialsharing/img/facebook.gif" alt="Facebook Like" /> -->
			</button>
							<button data-type="google-plus" type="button" class="btn btn-default btn-google-plus social-sharing">
				<i class="icon-google-plus"></i> گوگل+
				<!-- <img src="http://127.0.0.1:8888/prestashop/pos_bstore2/modules/socialsharing/img/google.gif" alt="Google Plus" /> -->
			</button>
							<button data-type="pinterest" type="button" class="btn btn-default btn-pinterest social-sharing">
				<i class="icon-pinterest"></i> پینترست
				<!-- <img src="http://127.0.0.1:8888/prestashop/pos_bstore2/modules/socialsharing/img/pinterest.gif" alt="Pinterest" /> -->
			</button>
			</p>
<?php }} ?>
