<?php /*%%SmartyHeaderCode:265255e352209fb597-85435460%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a62337d312e0f97ab5aee1cd9e662425c6a9b0c' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\productcomments\\productcomments_reviews.tpl',
      1 => 1433218420,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '265255e352209fb597-85435460',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e36d4766cbd0_79032738',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e36d4766cbd0_79032738')) {function content_55e36d4766cbd0_79032738($_smarty_tpl) {?>	<div class="comments_note" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<div class="star_content clearfix">
												<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
																<div class="star"></div>
							            <meta itemprop="worstRating" content = "0" />
            <meta itemprop="ratingValue" content = "0" />
            <meta itemprop="bestRating" content = "5" />
		</div>
		<span class="nb-comments"><span itemprop="reviewCount">0</span> نقد(ها)</span>
	</div>
<?php }} ?>
