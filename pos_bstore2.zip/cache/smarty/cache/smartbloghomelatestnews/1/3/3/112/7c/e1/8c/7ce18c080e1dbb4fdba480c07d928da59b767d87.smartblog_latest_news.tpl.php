<?php /*%%SmartyHeaderCode:2838555e35222a29053-34726673%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7ce18c080e1dbb4fdba480c07d928da59b767d87' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\smartbloghomelatestnews\\views\\templates\\front\\smartblog_latest_news.tpl',
      1 => 1434792742,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2838555e35222a29053-34726673',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e36d47c5a5e7_19619498',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e36d47c5a5e7_19619498')) {function content_55e36d47c5a5e7_19619498($_smarty_tpl) {?><div class="col-xs-12">
<div class="home_blog">
    <div class="title_block">
		<a class="blog_lnk" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/smartblog.html">
			آخرین اخبار
		</a>
		<div class="navi">
			<a class="prevtab"><i class="icon-angle-left"></i></a>
			<a class="nexttab"><i class="icon-angle-right"></i></a>
		</div>
	</div>
    <div class="block_content">
    <div class="row">
    <div class="blogSlider">
                                                                                                                <div class="blog_item">
                        <div class="blog_img_holder">
                             <a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/smartblog/6_اصول-طراحی-آبنما.html"><img alt="اصول طراحی آبنما" class="feat_img_small img-responsive" src="/prestashop/pos_bstore2/modules/smartblog/images/6-home-default.jpg"></a>
                        </div>
						<div class="blog_info">
							<a class="post_title" href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/smartblog/6_اصول-طراحی-آبنما.html">اصول طراحی آبنما</a>
							<p>
								&#1570;&#1576;&#1606;&#1605;&#1575; &#1575;&#1604;&#1605;&#1575;&#1606;&#1740;...
							</p>
							<span class="post_date"><i class="icon-calendar"></i>2015-08-30 19:25:15</span>
							<div class="rd_more">
								<a href="http://127.0.0.1:8888/prestashop/pos_bstore2/fa/smartblog/6_اصول-طراحی-آبنما.html">ادامه مطلب&nbsp;&nbsp;&nbsp;<i class="icon-long-arrow-right"></i></a>
							</div>
						</div>
                    </div>
                
                                         </div>
     </div>
     </div>
</div>
</div>
<script>
	$(document).ready(function() {
		var blogSlider = $(".blogSlider");
		blogSlider.owlCarousel({
			items : 4,
			itemsDesktop : [1199,3],
			itemsDesktopSmall : [991,3], 
			itemsTablet: [767,2], 
			itemsMobile : [480,1],
			autoPlay :  false,
			stopOnHover: false,
		});
		
		// Custom Navigation Events
		$(".home_blog .nexttab").click(function(){
		blogSlider.trigger('owl.next');})
		$(".home_blog .prevtab").click(function(){
		blogSlider.trigger('owl.prev');})   
	});
</script><?php }} ?>
