<?php /*%%SmartyHeaderCode:992455e3521f3b8b63-52646778%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c5fe02ca128c730d0371ac7a1a9690b3a4bf072c' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\themes\\pos_bstore1\\modules\\blockcontact\\blockcontact.tpl',
      1 => 1434941837,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '992455e3521f3b8b63-52646778',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e36d472c6be3_95246266',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e36d472c6be3_95246266')) {function content_55e36d472c6be3_95246266($_smarty_tpl) {?>	<div id="contact_block">
		<h3>تماس با ما</h3>
		<span>989155253009+</span>
	</div>
<?php }} ?>
