<?php /* Smarty version Smarty-3.1.19, created on 2015-08-30 23:29:51
         compiled from "E:\soheil\web_site_root\prestashop\pos_bstore2\admin3120tsmcd\themes\default\template\controllers\products\helpers\tree\tree_associated_header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2158955e352a7e1fb17-65398189%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0633bd0ea1f9b46f1386fcf7655dae04335f17c4' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\admin3120tsmcd\\themes\\default\\template\\controllers\\products\\helpers\\tree\\tree_associated_header.tpl',
      1 => 1425618560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2158955e352a7e1fb17-65398189',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'toolbar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e352a7e64021_53442693',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e352a7e64021_53442693')) {function content_55e352a7e64021_53442693($_smarty_tpl) {?>

<div class="tree-panel-heading-controls clearfix"><?php if (isset($_smarty_tpl->tpl_vars['toolbar']->value)) {?><?php echo $_smarty_tpl->tpl_vars['toolbar']->value;?>
<?php }?></div>
<?php }} ?>
