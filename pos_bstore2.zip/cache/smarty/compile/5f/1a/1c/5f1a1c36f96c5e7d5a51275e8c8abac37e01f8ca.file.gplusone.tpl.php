<?php /* Smarty version Smarty-3.1.19, created on 2015-08-31 00:36:48
         compiled from "E:\soheil\web_site_root\prestashop\pos_bstore2\modules\gplusone\gplusone.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1268555e362585ac165-26033986%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5f1a1c36f96c5e7d5a51275e8c8abac37e01f8ca' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\gplusone\\gplusone.tpl',
      1 => 1440964580,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1268555e362585ac165-26033986',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'gpo_default_hook' => 0,
    'gpo_layout' => 0,
    'gpo_count' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e362586393f7_89494690',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e362586393f7_89494690')) {function content_55e362586393f7_89494690($_smarty_tpl) {?><script type="text/javascript">
function track_plusone(gpovote) {
_gaq.push(['_trackEvent', 'Social Shares', 'Google +1 Vote', gpovote.href]);
}
</script>
<?php if ($_smarty_tpl->tpl_vars['gpo_default_hook']->value) {?>
<li>
<?php } else { ?>

<div class="gplusone_container">
<?php }?>
	<g:plusone size="<?php echo $_smarty_tpl->tpl_vars['gpo_layout']->value;?>
" count="<?php if ($_smarty_tpl->tpl_vars['gpo_count']->value=='1') {?>true<?php } else { ?>false<?php }?>"></g:plusone>
<?php if ($_smarty_tpl->tpl_vars['gpo_default_hook']->value) {?>
</li>
<?php } else { ?>
</div>
<?php }?><?php }} ?>
