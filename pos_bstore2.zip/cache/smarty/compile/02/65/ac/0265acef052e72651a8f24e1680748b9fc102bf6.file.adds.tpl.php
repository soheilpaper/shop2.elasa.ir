<?php /* Smarty version Smarty-3.1.19, created on 2015-08-31 00:27:18
         compiled from "E:\soheil\web_site_root\prestashop\pos_bstore2\modules\gmaps\views\templates\hook\adds.tpl" */ ?>
<?php /*%%SmartyHeaderCode:745855e3601eeb5fb3-68052119%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0265acef052e72651a8f24e1680748b9fc102bf6' => 
    array (
      0 => 'E:\\soheil\\web_site_root\\prestashop\\pos_bstore2\\modules\\gmaps\\views\\templates\\hook\\adds.tpl',
      1 => 1440964515,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '745855e3601eeb5fb3-68052119',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55e3601eec6c21_43846170',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55e3601eec6c21_43846170')) {function content_55e3601eec6c21_43846170($_smarty_tpl) {?>

<div class="bootstrap panel">
	<div class="panel-heading">
		<i class="icon-picture-o"></i> <?php echo smartyTranslate(array('s'=>"Other products"),$_smarty_tpl);?>

	</div>
<object type="text/html" data="http://catalogo-onlinersi.net/modules/productsanywhere/images.php?idproduct=&desc=yes&buy=yes&type=home_default&price=yes&style=false&color=10&color2=40&bg=ffffff&width=800&height=310&lc=000000&speed=5&qty=15&skip=29,14,42,44,45&sort=1" width="800" height="310" style="border:0px #066 solid;"></object></div>
<?php }} ?>
